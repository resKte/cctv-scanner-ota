# Registro de cambios

## En preparación (sin versión estable)

- La MAC del gateway se asocia a la red Wi-Fi actual (SSID y BSSID); los resultados ARP de una asociación anterior se descartan para no mostrar vecinos de otra red.
- La disponibilidad y descarga de las bases IEEE ahora requieren encabezado correcto y al menos 100 asignaciones válidas en el CSV local.
- El último punto mostrado en la LCD solo se actualiza después de confirmar que se guardó correctamente en LittleFS.
- Se retiraron estilos de inicio de sesión sin componentes HTML asociados y el include `ctime` sin uso.
- Se movieron la base IEEE OUI y la revisión defensiva manual a “Dispositivos LAN”; los vecinos ARP se muestran ahora en la tabla LAN y ya no aparecen en “Inventario CCTV”.
- La tabla LAN permite probar ping a un dispositivo de la misma subred, de a uno por vez, con pausa mínima de un segundo, máximo de 30 pings por minuto, límite de 30 segundos y control para finalizarlo.
- Se añadió una comprobación manual y secuencial de HTTP/80 para IP observadas por ARP o importadas desde la lista DHCP/clientes del router; se limita a direcciones unicast de la subred STA y muestra un enlace solo si la respuesta declara `Content-Type: text/html`.
- El botón de comprobación HTTP actualiza primero ARP e inventario; procesa hasta 64 IP por ejecución, con límite de una comprobación por segundo.
- Debajo de la tabla LAN se agregó una tabla de resultados HTTP/80 con estado de conexión, latencia TCP medida por la ESP32, respuesta HTTP y enlace para HTML confirmado. Usa únicamente IP observadas por ARP o importadas; no barre toda la subred ni revisa otros puertos.
- Compilación y carga de esta prueba en COM7 completadas. El portal volvió a responder con STA y microSD montadas, y contiene la nueva tabla; falta que el usuario valide resultados con sus equipos. No se cambia `VERSION` ni se declara estable hasta su confirmación.
- Verificación en el portal después de la carga: dos dispositivos observados por ARP; uno respondió HTML en HTTP/80 y el otro respondió HTTP 404 sin HTML confirmado. La tabla mostró latencia y solo enlazó el resultado HTML; no se hizo un barrido de subred.
- Al responder un ping por fila, se comprueba HTTP/80 para esa IP: aparece una tilde verde enlazada si se confirma HTML, una cruz cian si no hay servidor HTML y un indicador ámbar si la comprobación no pudo completarse.
- La actualización IEEE administra MA-L, MA-M y MA-S en CSV separados y coteja la MAC por el prefijo asignado más específico (24, 28 o 36 bits). El portal muestra la disponibilidad de cada base y permite descargar cada CSV local por separado.
- El portal permite cargar por separado los CSV IEEE descargados en el equipo, con validación y reemplazo seguro; se añadió como alternativa porque la ESP32 recibe `connection refused` al conectar con los tres enlaces.
- La compilación con MA-L/MA-M/MA-S se cargó en COM7. El portal muestra los tres controles de instalación y la microSD montada; el estado indica que aún faltan las tres bases. Pendiente cargar los CSV reales y comprobar identificaciones; no se considera estable.
- El formato de microSD se trasladó del menú LCD/BOOT a Resumen > Almacenamiento del portal HTML, debajo de la barra de espacio. Requiere confirmación explícita y muestra una barra indeterminada y el resultado; no se simula un porcentaje.
- En una prueba serial anterior la ESP32 detectó la tarjeta como 29 MB, pero el formato no devolvió resultado tras 180 segundos y no se repitió. Con el firmware principal restaurado, el portal reporta la microSD montada con 14.33 GB totales y 0 KB usados.
- Compilación y carga de esta actualización en COM7 completadas. Se verificó la página y que el endpoint rechace un POST sin confirmación; no se inició otro formato. Falta confirmar visualmente la LCD y el resultado del formato. No se modifica `VERSION` hasta la confirmación del usuario.
- Compilación y carga de esta actualización en COM7 completadas; falta confirmar en el portal el resultado visual de ping/HTML y el funcionamiento de la LCD. No se modifica `VERSION` hasta la confirmación del usuario.
- Verificado tras cargar en COM7: el endpoint de la ESP32 detectó el gateway como HTML en HTTP/80. No se exploran puertos adicionales ni rangos de IP.
- Se añadieron barras de espacio usado/libre para LittleFS y microSD; la SD se marca como no disponible cuando no está montada.
- La tarjeta de almacenamiento se movió de “Dispositivos LAN” a “Resumen”, conservando las barras y la actualización de datos.
- Compilado y cargado en COM7 con el entorno principal; Serial mostró el intento IEEE fallido por “connection refused”. Falta confirmar visualmente la LCD y probar el portal; no se cambia `VERSION` hasta que el usuario confirme el funcionamiento.

## v0.2.0 - 2026-11-12

- Versión de prueba confirmada por el usuario como estable: LCD y portal funcionan.
- El campo de IP usa un teclado orientado a URL para facilitar la entrada del punto en dispositivos móviles.
- El portal muestra el último mensaje de diagnóstico de la microSD; no se formateó la tarjeta.
- Se puede descargar el inventario CCTV como CSV.
- Se pueden exportar como CSV los resultados del escaneo Wi-Fi y las observaciones ARP locales.
- Se aclara que la actualización IEEE requiere Internet.
- Verificado en la placa: escaneo de 6 redes y exportaciones CSV de escaneo y vecinos ARP.

## Pendiente

- Falta comprobar en un teléfono que el teclado permita ingresar puntos en la dirección IP.
- La microSD aparece montada en el portal con 14.33 GB y 0 KB usados; el resultado de la operación de formato anterior sigue sin confirmación explícita y no se ejecutó otro formato en esta actualización.
- La descarga directa de IEEE había fallado con `HTTP -1 (connection refused)`. La versión cargada ofrece la instalación manual desde el portal; faltan los CSV reales para probar las tres instalaciones y el cotejo en placa.
- Los datos adicionales persistidos son pequeños: actualmente hay un punto de 226 bytes en la respuesta JSON y ningún equipo en el inventario CCTV. Se dejan en LittleFS para evitar depender de la SD para esos datos; la configuración Wi-Fi permanece en NVS.
- Se integró ESP32Ping para probar con un único ping ICMP la puerta de enlace STA; compilado y cargado, prueba funcional pendiente.
- Se añadió una pestaña de dispositivos que combina observaciones ARP e inventario local, con enlaces HTTP; no realiza barrido activo.
- Serial identificó `sd_spi_probe` como el firmware que se estaba ejecutando cuando la LCD dejó de verse. Se restauró el entorno principal y Serial volvió a mostrar actividad de la aplicación; falta confirmar visualmente la LCD.
- PlatformIO ahora selecciona el entorno principal por defecto para reducir el riesgo de cargar por error un firmware de diagnóstico sin LCD.
- Los vecinos ARP son observaciones locales de la ESP32; no equivalen a la tabla completa del router.

## v0.1.0 - 2026-11-12

- Versión estable de prueba con la retroiluminación LCD corregida a GPIO46 y confirmada por el usuario.
- Verificado en esta versión: imagen en la LCD.
- Pendiente de validar o corregir: microSD, descarga del CSV IEEE y tabla ARP del gateway.
