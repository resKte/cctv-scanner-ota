#include <Arduino.h>
#include <Arduino_GFX_Library.h>
#include <DNSServer.h>
#include <ESP32Ping.h>
#include <HTTPClient.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <qrcode.h>
#include <SD_MMC.h>
#include <WebServer.h>
#include <WiFi.h>
#include <WiFiClient.h>
#include <WiFiProv.h>
#include <esp_netif.h>
#include <esp_netif_net_stack.h>
#include <esp_mac.h>
#include <esp_err.h>
#include <esp_wifi.h>
#include <driver/sdmmc_host.h>
#include <esp_vfs_fat.h>
#include <lwip/etharp.h>
#include <lwip/opt.h>
#include <lwip/tcpip.h>
#include <sdmmc_cmd.h>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <vector>

#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include <freertos/task.h>

namespace {

constexpr int PIN_LCD_DC = 41;
constexpr int PIN_LCD_CS = 42;
constexpr int PIN_LCD_SCLK = 40;
constexpr int PIN_LCD_MOSI = 45;
constexpr int PIN_LCD_RST = 39;
constexpr int PIN_LCD_BL = 46;
constexpr int PIN_BOOT = 0;
constexpr int PIN_SD_CLK = SD_CLK;
constexpr int PIN_SD_CMD = SD_CMD;
constexpr int PIN_SD_D0 = SD_D0;
constexpr int SCREEN_WIDTH = 172;
constexpr int SCREEN_HEIGHT = 320;
constexpr uint8_t SCREEN_ROTATION = 0;
constexpr uint8_t MAX_SAVED_NETWORKS = 5;
constexpr size_t MAX_TEST_BYTES = 1024 * 1024;
constexpr char AP_SSID[] = "ESP32-SiteSurvey";
constexpr char AP_PASSWORD[] = "12345678";
constexpr char POINTS_FILE[] = "/points.csv";
constexpr char CCTV_ASSETS_FILE[] = "/cctv_assets.csv";
constexpr char OUI_DIRECTORY[] = "/ieee";
constexpr char OUI_FILE[] = "/ieee/oui.csv";
constexpr char OUI_TEMP_FILE[] = "/ieee/oui.csv.tmp";
constexpr char OUI_BACKUP_FILE[] = "/ieee/oui.csv.bak";
constexpr char OUI_URL[] = "http://standards-oui.ieee.org/oui/oui.csv";
constexpr char OUI_MAM_FILE[] = "/ieee/mam.csv";
constexpr char OUI_MAM_TEMP_FILE[] = "/ieee/mam.csv.tmp";
constexpr char OUI_MAM_BACKUP_FILE[] = "/ieee/mam.csv.bak";
constexpr char OUI_MAM_URL[] = "http://standards-oui.ieee.org/oui28/mam.csv";
constexpr char OUI_MAS_FILE[] = "/ieee/oui36.csv";
constexpr char OUI_MAS_TEMP_FILE[] = "/ieee/oui36.csv.tmp";
constexpr char OUI_MAS_BACKUP_FILE[] = "/ieee/oui36.csv.bak";
constexpr char OUI_MAS_URL[] = "http://standards-oui.ieee.org/oui36/oui36.csv";

struct OuiDatabase {
  const char *registry;
  const char *filePath;
  const char *temporaryPath;
  const char *backupPath;
  const char *url;
  const char *etagKey;
  const char *modifiedKey;
  uint8_t assignmentHexDigits;
  const char *downloadFilename;
};

constexpr OuiDatabase OUI_DATABASES[] = {
    {"MA-L", OUI_FILE, OUI_TEMP_FILE, OUI_BACKUP_FILE, OUI_URL, "etagL",
     "modL", 6, "ieee_oui.csv"},
    {"MA-M", OUI_MAM_FILE, OUI_MAM_TEMP_FILE, OUI_MAM_BACKUP_FILE,
     OUI_MAM_URL, "etagM", "modM", 7, "ieee_mam.csv"},
    {"MA-S", OUI_MAS_FILE, OUI_MAS_TEMP_FILE, OUI_MAS_BACKUP_FILE,
     OUI_MAS_URL, "etagS", "modS", 9, "ieee_oui36.csv"},
};
constexpr size_t OUI_DATABASE_COUNT =
    sizeof(OUI_DATABASES) / sizeof(OUI_DATABASES[0]);

Arduino_DataBus *displayBus = new Arduino_ESP32SPI(
    PIN_LCD_DC, PIN_LCD_CS, PIN_LCD_SCLK, PIN_LCD_MOSI, GFX_NOT_DEFINED);
Arduino_GFX *display = new Arduino_ST7789(
    displayBus, PIN_LCD_RST, SCREEN_ROTATION, true, SCREEN_WIDTH, SCREEN_HEIGHT,
    34, 0, 34, 0);

WebServer server(80);
DNSServer dnsServer;
Preferences preferences;
IPAddress apAddress(192, 168, 4, 1);
IPAddress apMask(255, 255, 255, 0);

struct SavedNetwork {
  String ssid;
  String password;
};

struct ScannedNetwork {
  String ssid;
  String bssid;
  int32_t rssi;
  uint8_t channel;
  wifi_auth_mode_t auth;
};

struct SurveyPoint {
  uint32_t uptimeMs;
  String name;
  float mbps;
  int32_t rssi;
  uint8_t channel;
  float latencyMs;
};

struct CctvAsset {
  String ip;
  String name;
  String type;
  String mac;
  String manufacturer;
  String model;
  String firmware;
};

struct OuiLookupEntry {
  String prefix;
  String manufacturer;
};

struct ArpSnapshotEntry {
  char ip[16];
  uint8_t mac[6];
};

struct ArpObservation {
  String ip;
  String mac;
  uint32_t lastSeenAt;
};

struct PointAnalysis {
  uint8_t score;
  String quality;
  String recommendation;
  String anomaly;
};

enum class BootQrScreen : uint8_t {
  Status,
  WifiProvisioning,
  StaPortal,
  SdCard
};

std::vector<SavedNetwork> savedNetworks;
std::vector<ScannedNetwork> scanResults;
std::vector<CctvAsset> cctvAssets;
std::vector<OuiLookupEntry> ouiLookupCache;
std::vector<ArpObservation> arpObservations;
ArpSnapshotEntry arpSnapshot[ARP_TABLE_SIZE] = {};
size_t arpSnapshotCount = 0;
bool arpSnapshotReady = false;
SemaphoreHandle_t ouiFileMutex = nullptr;
String connectionMessage = "Esperando red STA";
String lastNetworkError;
String latestPointName;
PointAnalysis latestAnalysis{0, "Sin datos", "Ejecuta una medición para analizar el punto", ""};
SavedNetwork pendingNetwork;
bool rememberPendingNetwork = false;
bool connectionAttemptActive = false;
bool filesystemReady = false;
bool sdCardReady = false;
bool ouiStorageOnSd = false;
volatile bool sdFormatRunning = false;
volatile bool sdFormatSucceeded = false;
bool sdFormatAttempted = false;
String sdLastMessage = "Tarjeta no inicializada";
bool preferencesReady = false;
bool accessPointReady = false;
bool displayReady = false;
bool dnsServerReady = false;
bool bleProvisioningActive = false;
bool bleProvisioningRequested = false;
bool ouiUpdateRunning = false;
bool ouiUpdateAttempted = false;
bool ouiUpdateSucceeded = false;
bool ouiUploadRunning = false;
bool ouiUploadSucceeded = false;
int ouiUploadErrorStatus = 400;
size_t ouiUploadBytes = 0;
const OuiDatabase *ouiUploadDatabase = nullptr;
File ouiUploadFile;
String ouiUploadError;
bool staWasConnected = false;
String gatewayMac;
String gatewayMacIp;
String gatewayMacNetwork;
String gatewayObservedIp;
String gatewayObservedNetwork;
String gatewayArpRequestedIp;
char gatewayArpRequestedNetwork[51] = {};
char arpSnapshotNetwork[sizeof(gatewayArpRequestedNetwork)] = {};
uint32_t nextGatewayArpLookupAt = 0;
uint32_t nextGatewayArpRequestAt = 0;
uint32_t lastGatewayPingAt = 0;
bool gatewayPingAttempted = false;
uint32_t lastDevicePingAt = 0;
bool devicePingAttempted = false;
uint32_t devicePingWindowStartedAt = 0;
uint8_t devicePingAttemptsInWindow = 0;
bool devicePingWindowStarted = false;
uint32_t lastHttpProbeAt = 0;
bool httpProbeAttempted = false;
uint32_t httpProbeWindowStartedAt = 0;
uint8_t httpProbeAttemptsInWindow = 0;
bool httpProbeWindowStarted = false;
uint32_t nextOuiUpdateAt = 0;
bool gatewayArpCallbackPending = false;
bool gatewayArpResultReady = false;
bool gatewayArpShouldRequest = false;
uint8_t gatewayArpResultMac[6] = {};
int32_t gatewayArpRequestError = 0;
bool gatewayArpNetifError = false;
ip4_addr_t gatewayArpTargetIp = {};
portMUX_TYPE gatewayArpMux = portMUX_INITIALIZER_UNLOCKED;
BootQrScreen bootQrScreen = BootQrScreen::Status;
char bleServiceName[20] = "Prov_SiteSurvey";
char bleProofOfPossession[9] = "S3LCD147";
portMUX_TYPE bleEventMux = portMUX_INITIALIZER_UNLOCKED;
bool bleStartPending = false;
bool bleSuccessPending = false;
bool bleFailurePending = false;
bool bleAuthFailurePending = false;
bool bleCredentialsPending = false;
char bleReceivedSsid[33] = {};
char bleReceivedPassword[65] = {};
uint32_t connectionAttemptAt = 0;
uint32_t nextReconnectAt = 0;
uint32_t nextScreenRefreshAt = 0;
size_t reconnectIndex = 0;

void startBleProvisioning(bool force);

String jsonEscape(const String &value) {
  String escaped;
  escaped.reserve(value.length() + 8);
  for (size_t i = 0; i < value.length(); ++i) {
    const char c = value[i];
    switch (c) {
    case '"':
      escaped += F("\\\"");
      break;
    case '\\':
      escaped += F("\\\\");
      break;
    case '\b':
      escaped += F("\\b");
      break;
    case '\f':
      escaped += F("\\f");
      break;
    case '\n':
      escaped += F("\\n");
      break;
    case '\r':
      escaped += F("\\r");
      break;
    case '\t':
      escaped += F("\\t");
      break;
    default:
      if (static_cast<uint8_t>(c) < 0x20) {
        escaped += ' ';
      } else {
        escaped += c;
      }
    }
  }
  return escaped;
}

String csvEscape(const String &value) {
  String escaped;
  escaped.reserve(value.length() + 4);
  bool quote = false;
  for (size_t i = 0; i < value.length(); ++i) {
    const char c = value[i];
    if (c == '"') {
      escaped += F("\"\"");
      quote = true;
    } else {
      if (c == ',' || c == '\n' || c == '\r') {
        quote = true;
      }
      escaped += c;
    }
  }
  if (quote) {
    escaped = String("\"") + escaped + '"';
  }
  return escaped;
}

void sendJson(int statusCode, const String &body) {
  server.sendHeader("Cache-Control", "no-store");
  server.send(statusCode, "application/json; charset=utf-8", body);
}

void sendError(int statusCode, const String &message) {
  String body = F("{\"error\":\"");
  body += jsonEscape(message);
  body += F("\"}");
  sendJson(statusCode, body);
}

bool requireSession() {
  // El portal queda abierto por solicitud; cualquier cliente que lo alcance
  // puede consultar y modificar sus datos.
  return true;
}

String encryptionLabel(wifi_auth_mode_t auth) {
  switch (auth) {
  case WIFI_AUTH_OPEN:
    return F("Abierta");
  case WIFI_AUTH_WEP:
    return F("WEP");
  case WIFI_AUTH_WPA_PSK:
    return F("WPA");
  case WIFI_AUTH_WPA2_PSK:
    return F("WPA2");
  case WIFI_AUTH_WPA_WPA2_PSK:
    return F("WPA/WPA2");
  case WIFI_AUTH_WPA3_PSK:
    return F("WPA3");
  case WIFI_AUTH_WPA2_WPA3_PSK:
    return F("WPA2/WPA3");
  default:
    return F("Otro");
  }
}

String riskLabel(wifi_auth_mode_t auth) {
  if (auth == WIFI_AUTH_OPEN || auth == WIFI_AUTH_WEP) {
    return F("Vulnerable / Riesgo alto");
  }
  if (auth == WIFI_AUTH_WPA3_PSK) {
    return F("Protegido (WPA3)");
  }
  if (auth == WIFI_AUTH_WPA2_WPA3_PSK) {
    return F("Modo mixto / Revisar");
  }
  return F("Estándar / Revisar WPS");
}

String scanResultsJson() {
  String body;
  body.reserve(256 + scanResults.size() * 180);
  body = '[';
  for (size_t i = 0; i < scanResults.size(); ++i) {
    const ScannedNetwork &network = scanResults[i];
    if (i != 0) {
      body += ',';
    }
    body += F("{\"ssid\":\"");
    body += jsonEscape(network.ssid);
    body += F("\",\"bssid\":\"");
    body += jsonEscape(network.bssid);
    body += F("\",\"rssi\":");
    body += String(network.rssi);
    body += F(",\"channel\":");
    body += String(network.channel);
    body += F(",\"encryption\":\"");
    body += encryptionLabel(network.auth);
    body += F("\",\"risk\":\"");
    body += riskLabel(network.auth);
    body += F("\"}");
  }
  body += ']';
  return body;
}

bool persistSavedNetworks() {
  if (!preferencesReady) {
    return false;
  }

  for (uint8_t i = 0; i < MAX_SAVED_NETWORKS; ++i) {
    const String ssidKey = "s" + String(i);
    const String passwordKey = "p" + String(i);
    preferences.remove(ssidKey.c_str());
    preferences.remove(passwordKey.c_str());
  }

  for (size_t i = 0; i < savedNetworks.size(); ++i) {
    const String ssidKey = "s" + String(i);
    const String passwordKey = "p" + String(i);
    if (preferences.putString(ssidKey.c_str(), savedNetworks[i].ssid) == 0 ||
        preferences.putString(passwordKey.c_str(), savedNetworks[i].password) ==
            0) {
      Serial.println(F("ERROR: no se pudo persistir la lista Wi-Fi en NVS"));
      return false;
    }
  }
  return true;
}

void loadSavedNetworks() {
  savedNetworks.clear();
  if (!preferencesReady) {
    return;
  }

  for (uint8_t i = 0; i < MAX_SAVED_NETWORKS; ++i) {
    const String ssidKey = "s" + String(i);
    const String passwordKey = "p" + String(i);
    const String ssid = preferences.getString(ssidKey.c_str(), "");
    if (ssid.isEmpty()) {
      continue;
    }
    savedNetworks.push_back(
        {ssid, preferences.getString(passwordKey.c_str(), "")});
  }
}

bool rememberNetwork(const SavedNetwork &network) {
  savedNetworks.erase(
      std::remove_if(savedNetworks.begin(), savedNetworks.end(),
                     [&network](const SavedNetwork &saved) {
                       return saved.ssid == network.ssid;
                     }),
      savedNetworks.end());
  savedNetworks.insert(savedNetworks.begin(), network);
  if (savedNetworks.size() > MAX_SAVED_NETWORKS) {
    savedNetworks.resize(MAX_SAVED_NETWORKS);
  }
  return persistSavedNetworks();
}

String ouiHexDigits(const String &value) {
  String digits;
  digits.reserve(value.length());
  for (size_t i = 0; i < value.length(); ++i) {
    const unsigned char character = static_cast<unsigned char>(value[i]);
    if (std::isxdigit(character)) {
      digits += static_cast<char>(std::toupper(character));
    } else if (character != ':' && character != '-' && character != '.' &&
               !std::isspace(character)) {
      return "";
    }
  }
  return digits;
}

String ouiMacHex(const String &value) {
  const String digits = ouiHexDigits(value);
  return digits.length() == 12 ? digits : String();
}

std::vector<String> parseCsvFields(const String &line) {
  std::vector<String> fields;
  String field;
  bool quoted = false;
  for (size_t i = 0; i < line.length(); ++i) {
    const char character = line[i];
    if (character == '"') {
      if (quoted && i + 1 < line.length() && line[i + 1] == '"') {
        field += '"';
        ++i;
      } else {
        quoted = !quoted;
      }
    } else if (character == ',' && !quoted) {
      field.trim();
      fields.push_back(field);
      field = "";
    } else {
      field += character;
    }
  }
  field.trim();
  fields.push_back(field);
  return fields;
}

fs::FS &ouiStorage() {
  return sdCardReady && ouiStorageOnSd ? static_cast<fs::FS &>(SD_MMC)
                                       : static_cast<fs::FS &>(LittleFS);
}

bool isOuiStorageReady() {
  return (sdCardReady && ouiStorageOnSd) || filesystemReady;
}

uint64_t ouiStorageFreeBytes() {
  const bool useSd = sdCardReady && ouiStorageOnSd;
  const uint64_t total = useSd ? SD_MMC.totalBytes() : LittleFS.totalBytes();
  const uint64_t used = useSd ? SD_MMC.usedBytes() : LittleFS.usedBytes();
  return total > used ? total - used : 0;
}

bool validateOuiFile(fs::FS &filesystem, const OuiDatabase &database,
                     const char *path) {
  File file = filesystem.open(path, FILE_READ);
  if (!file) {
    return false;
  }

  String header = file.readStringUntil('\n');
  header.trim();
  header.toLowerCase();
  const bool validHeader = header.indexOf("registry") >= 0 &&
                           header.indexOf("assignment") >= 0 &&
                           header.indexOf("organization name") >= 0;
  size_t rows = 0;
  while (validHeader && file.available() && rows < 100) {
    String line = file.readStringUntil('\n');
    line.trim();
    if (line.isEmpty()) {
      continue;
    }
    const std::vector<String> fields = parseCsvFields(line);
    if (fields.size() < 3 || !fields[0].equalsIgnoreCase(database.registry) ||
        ouiHexDigits(fields[1]).length() != database.assignmentHexDigits ||
        fields[2].isEmpty()) {
      continue;
    }
    ++rows;
  }
  file.close();
  return validHeader && rows >= 100;
}

bool ouiDatabaseAvailable(const OuiDatabase &database) {
  return isOuiStorageReady() &&
         validateOuiFile(ouiStorage(), database, database.filePath);
}

String ouiManufacturerForMac(const String &mac) {
  const String macHex = ouiMacHex(mac);
  if (macHex.isEmpty() || ouiFileMutex == nullptr ||
      xSemaphoreTake(ouiFileMutex, pdMS_TO_TICKS(1000)) != pdTRUE) {
    return "";
  }

  size_t cachedPrefixLength = 0;
  String cachedManufacturer;
  bool cacheHit = false;
  for (const OuiLookupEntry &entry : ouiLookupCache) {
    if (entry.prefix.length() > cachedPrefixLength &&
        macHex.startsWith(entry.prefix)) {
      cachedPrefixLength = entry.prefix.length();
      cachedManufacturer = entry.manufacturer;
      cacheHit = true;
    }
  }
  if (cacheHit) {
    xSemaphoreGive(ouiFileMutex);
    return cachedManufacturer;
  }

  String manufacturer;
  String matchedPrefix;
  for (int databaseIndex = static_cast<int>(OUI_DATABASE_COUNT) - 1;
       databaseIndex >= 0 && manufacturer.isEmpty(); --databaseIndex) {
    const OuiDatabase &database = OUI_DATABASES[databaseIndex];
    File file = ouiStorage().open(database.filePath, FILE_READ);
    if (!file) {
      continue;
    }
    file.readStringUntil('\n');
    while (file.available()) {
      const String line = file.readStringUntil('\n');
      const std::vector<String> fields = parseCsvFields(line);
      if (fields.size() < 3 ||
          !fields[0].equalsIgnoreCase(database.registry)) {
        continue;
      }
      const String assignment = ouiHexDigits(fields[1]);
      if (assignment.length() != database.assignmentHexDigits ||
          !macHex.startsWith(assignment) || fields[2].isEmpty()) {
        continue;
      }
      matchedPrefix = assignment;
      manufacturer = fields[2];
      break;
    }
    file.close();
  }

  if (ouiLookupCache.size() >= 128) {
    ouiLookupCache.erase(ouiLookupCache.begin());
  }
  ouiLookupCache.push_back(
      {matchedPrefix.isEmpty() ? macHex : matchedPrefix, manufacturer});
  xSemaphoreGive(ouiFileMutex);
  return manufacturer;
}

bool installOuiTempDatabase(fs::FS &filesystem,
                            const OuiDatabase &database) {
  if (ouiFileMutex == nullptr ||
      xSemaphoreTake(ouiFileMutex, pdMS_TO_TICKS(2000)) != pdTRUE) {
    Serial.printf("IEEE %s: no se pudo bloquear la base para reemplazarla\n",
                  database.registry);
    return false;
  }

  if (filesystem.exists(database.backupPath) &&
      !filesystem.remove(database.backupPath)) {
    xSemaphoreGive(ouiFileMutex);
    Serial.printf("IEEE %s: no se pudo limpiar la copia de respaldo\n",
                  database.registry);
    return false;
  }
  const bool hadDatabase = filesystem.exists(database.filePath);
  if (hadDatabase &&
      !filesystem.rename(database.filePath, database.backupPath)) {
    xSemaphoreGive(ouiFileMutex);
    Serial.printf("IEEE %s: no se pudo respaldar la base vigente\n",
                  database.registry);
    return false;
  }
  if (!filesystem.rename(database.temporaryPath, database.filePath)) {
    if (hadDatabase) {
      filesystem.rename(database.backupPath, database.filePath);
    }
    xSemaphoreGive(ouiFileMutex);
    Serial.printf("IEEE %s: no se pudo instalar la base nueva; se conservó la anterior\n",
                  database.registry);
    return false;
  }
  if (hadDatabase && !filesystem.remove(database.backupPath)) {
    Serial.printf("IEEE %s: aviso: quedó una copia de respaldo\n",
                  database.registry);
  }
  ouiLookupCache.clear();
  xSemaphoreGive(ouiFileMutex);
  return true;
}

bool updateOuiDatabase(fs::FS &filesystem, Preferences &cachePreferences,
                       const OuiDatabase &database) {
  const bool hasDatabase =
      filesystem.exists(database.filePath) &&
      validateOuiFile(filesystem, database, database.filePath);
  const String etag =
      hasDatabase ? cachePreferences.getString(database.etagKey, "") : "";
  const String lastModified =
      hasDatabase ? cachePreferences.getString(database.modifiedKey, "") : "";
  WiFiClient httpClient;
  httpClient.setTimeout(15000);
  HTTPClient http;
  http.setConnectTimeout(12000);
  http.setTimeout(15000);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setAcceptEncoding("identity");
  if (!http.begin(httpClient, database.url)) {
    Serial.printf("IEEE %s: no se pudo iniciar HTTP\n", database.registry);
    return false;
  }

  const char *responseHeaders[] = {"ETag", "Last-Modified"};
  http.collectHeaders(responseHeaders, 2);
  if (!etag.isEmpty()) {
    http.addHeader("If-None-Match", etag);
  }
  if (!lastModified.isEmpty()) {
    http.addHeader("If-Modified-Since", lastModified);
  }

  const int status = http.GET();
  if (status == HTTP_CODE_NOT_MODIFIED && hasDatabase) {
    http.end();
    Serial.printf("IEEE %s: la copia local ya está actualizada\n",
                  database.registry);
    return true;
  }
  if (status != HTTP_CODE_OK) {
    Serial.printf("IEEE %s: HTTP devolvió %d (%s)\n", database.registry,
                  status,
                  http.errorToString(status).c_str());
    http.end();
    return false;
  }

  const int contentLength = http.getSize();
  constexpr size_t MAX_OUI_BYTES = 8U * 1024U * 1024U;
  const uint64_t freeBytes = ouiStorageFreeBytes();
  if (contentLength < 1000 ||
      static_cast<size_t>(contentLength) > MAX_OUI_BYTES ||
      freeBytes < static_cast<uint64_t>(contentLength) + 4096U) {
    Serial.printf("IEEE %s: tamaño o espacio inválido (contenido=%d, libre=%llu)\n",
                  database.registry, contentLength,
                  static_cast<unsigned long long>(freeBytes));
    http.end();
    return false;
  }

  if (filesystem.exists(database.temporaryPath) &&
      !filesystem.remove(database.temporaryPath)) {
    Serial.printf("IEEE %s: no se pudo limpiar el archivo temporal\n",
                  database.registry);
    http.end();
    return false;
  }
  File tempFile = filesystem.open(database.temporaryPath, FILE_WRITE);
  if (!tempFile) {
    Serial.printf("IEEE %s: no se pudo crear el archivo temporal\n",
                  database.registry);
    http.end();
    return false;
  }
  const int written = http.writeToStream(&tempFile);
  tempFile.flush();
  const size_t downloadedBytes = tempFile.size();
  tempFile.close();
  const String responseEtag = http.header("ETag");
  const String responseModified = http.header("Last-Modified");
  http.end();

  if (written != contentLength ||
      downloadedBytes != static_cast<size_t>(contentLength) ||
      !validateOuiFile(filesystem, database, database.temporaryPath)) {
    filesystem.remove(database.temporaryPath);
    Serial.printf("IEEE %s: CSV incompleto o inválido (escritos=%d, esperados=%d)\n",
                  database.registry, written, contentLength);
    return false;
  }

  if (!installOuiTempDatabase(filesystem, database)) {
    filesystem.remove(database.temporaryPath);
    return false;
  }

  cachePreferences.putString(database.etagKey, responseEtag);
  cachePreferences.putString(database.modifiedKey, responseModified);
  Serial.printf("IEEE %s: base actualizada (%u bytes)\n", database.registry,
                static_cast<unsigned>(downloadedBytes));
  return true;
}

bool runOuiUpdate() {
  if (!isOuiStorageReady() || WiFi.status() != WL_CONNECTED) {
    Serial.println(F("IEEE: actualización omitida; almacenamiento o STA no disponible"));
    return false;
  }
  fs::FS &filesystem = ouiStorage();
  if (!filesystem.exists(OUI_DIRECTORY) &&
      !filesystem.mkdir(OUI_DIRECTORY)) {
    Serial.println(F("IEEE: no se pudo crear /ieee en el almacenamiento"));
    return false;
  }

  Preferences cachePreferences;
  if (!cachePreferences.begin("oui-cache", false)) {
    Serial.println(F("IEEE: no se pudo abrir la caché de validadores"));
    return false;
  }

  bool allUpdated = true;
  for (const OuiDatabase &database : OUI_DATABASES) {
    if (!updateOuiDatabase(filesystem, cachePreferences, database)) {
      allUpdated = false;
    }
  }
  cachePreferences.end();
  if (!allUpdated) {
    Serial.println(F("IEEE: actualización incompleta; se conservan las bases locales válidas"));
  }
  return allUpdated;
}

void ouiUpdateTask(void *) {
  ouiUpdateSucceeded = runOuiUpdate();
  ouiUpdateAttempted = true;
  nextOuiUpdateAt =
      millis() + (ouiUpdateSucceeded ? 24UL * 60UL * 60UL * 1000UL
                                     : 15UL * 60UL * 1000UL);
  ouiUpdateRunning = false;
  vTaskDelete(nullptr);
}

bool scheduleOuiUpdate() {
  if (ouiUpdateRunning || ouiUploadRunning) {
    return false;
  }
  ouiUpdateRunning = true;
  if (xTaskCreatePinnedToCore(ouiUpdateTask, "oui-update", 12288, nullptr, 1,
                              nullptr, 1) != pdPASS) {
    ouiUpdateRunning = false;
    nextOuiUpdateAt = millis() + 30000UL;
    Serial.println(F("IEEE OUI: no se pudo iniciar la tarea de actualización"));
    return false;
  }
  return true;
}

void maintainOuiUpdate() {
  if (WiFi.status() != WL_CONNECTED || ouiUpdateRunning || ouiUploadRunning ||
      (nextOuiUpdateAt != 0 &&
       static_cast<int32_t>(millis() - nextOuiUpdateAt) < 0)) {
    return;
  }
  scheduleOuiUpdate();
}

String formatMacAddress(const uint8_t mac[6]) {
  char formatted[18];
  snprintf(formatted, sizeof(formatted), "%02X:%02X:%02X:%02X:%02X:%02X",
           mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  return String(formatted);
}

void gatewayArpLookupCallback(void *) {
  bool found = false;
  bool netifError = false;
  int32_t requestError = 0;
  uint8_t mac[6] = {};
  ArpSnapshotEntry snapshot[ARP_TABLE_SIZE] = {};
  size_t snapshotCount = 0;
  esp_netif_t *staNetif = esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");
  struct netif *lwipNetif =
      staNetif != nullptr
          ? static_cast<struct netif *>(esp_netif_get_netif_impl(staNetif))
          : nullptr;

  if (lwipNetif == nullptr) {
    netifError = true;
  } else {
    for (size_t i = 0; i < ARP_TABLE_SIZE; ++i) {
      ip4_addr_t *entryIp = nullptr;
      struct netif *entryNetif = nullptr;
      struct eth_addr *entryMac = nullptr;
      if (etharp_get_entry(i, &entryIp, &entryNetif, &entryMac) != 1 ||
          entryIp == nullptr || entryMac == nullptr ||
          entryNetif != lwipNetif) {
        continue;
      }
      ip4addr_ntoa_r(entryIp, snapshot[snapshotCount].ip,
                     sizeof(snapshot[snapshotCount].ip));
      for (size_t byte = 0; byte < sizeof(snapshot[snapshotCount].mac); ++byte) {
        snapshot[snapshotCount].mac[byte] = entryMac->addr[byte];
      }
      ++snapshotCount;
    }

    struct eth_addr *ethernetAddress = nullptr;
    const ip4_addr_t *resolvedAddress = nullptr;
    if (etharp_find_addr(lwipNetif, &gatewayArpTargetIp, &ethernetAddress,
                         &resolvedAddress) >= 0 &&
        ethernetAddress != nullptr) {
      for (size_t i = 0; i < sizeof(mac); ++i) {
        mac[i] = ethernetAddress->addr[i];
      }
      found = true;
    } else if (gatewayArpShouldRequest) {
      requestError = static_cast<int32_t>(
          etharp_request(lwipNetif, &gatewayArpTargetIp));
    }
  }

  portENTER_CRITICAL(&gatewayArpMux);
  gatewayArpNetifError = netifError;
  gatewayArpRequestError = requestError;
  for (size_t i = 0; i < snapshotCount; ++i) {
    arpSnapshot[i] = snapshot[i];
  }
  memcpy(arpSnapshotNetwork, gatewayArpRequestedNetwork,
         sizeof(arpSnapshotNetwork));
  arpSnapshotCount = snapshotCount;
  arpSnapshotReady = true;
  if (found) {
    for (size_t i = 0; i < sizeof(mac); ++i) {
      gatewayArpResultMac[i] = mac[i];
    }
    gatewayArpResultReady = true;
  }
  gatewayArpCallbackPending = false;
  portEXIT_CRITICAL(&gatewayArpMux);
}

void maintainGatewayMac() {
  if (WiFi.status() != WL_CONNECTED) {
    gatewayObservedIp = "";
    gatewayObservedNetwork = "";
    nextGatewayArpLookupAt = 0;
    nextGatewayArpRequestAt = 0;
    return;
  }

  const IPAddress gateway = WiFi.gatewayIP();
  const String currentGatewayIp = gateway.toString();
  const String currentGatewayNetwork = WiFi.SSID() + "|" + WiFi.BSSIDstr();
  if (currentGatewayIp == "0.0.0.0") {
    return;
  }
  if (currentGatewayIp != gatewayObservedIp ||
      currentGatewayNetwork != gatewayObservedNetwork) {
    gatewayObservedIp = currentGatewayIp;
    gatewayObservedNetwork = currentGatewayNetwork;
    nextGatewayArpLookupAt = millis();
    nextGatewayArpRequestAt = millis();
    if (!gatewayMac.isEmpty() &&
        (gatewayMacIp != currentGatewayIp ||
         gatewayMacNetwork != currentGatewayNetwork)) {
      gatewayMac = "";
      gatewayMacIp = "";
      gatewayMacNetwork = "";
      if (preferencesReady) {
        preferences.remove("gwmac");
        preferences.remove("gwip");
        preferences.remove("gwnet");
      }
    }
  }

  bool resultReady = false;
  bool netifError = false;
  int32_t requestError = 0;
  uint8_t resultMac[6] = {};
  portENTER_CRITICAL(&gatewayArpMux);
  resultReady = gatewayArpResultReady;
  if (resultReady) {
    for (size_t i = 0; i < sizeof(resultMac); ++i) {
      resultMac[i] = gatewayArpResultMac[i];
    }
    gatewayArpResultReady = false;
  }
  netifError = gatewayArpNetifError;
  gatewayArpNetifError = false;
  requestError = gatewayArpRequestError;
  gatewayArpRequestError = 0;
  const bool callbackPending = gatewayArpCallbackPending;
  portEXIT_CRITICAL(&gatewayArpMux);

  if (netifError) {
    Serial.println(F("Gateway ARP: no se encontró la interfaz Wi-Fi STA de lwIP"));
  }
  if (requestError != 0) {
    Serial.printf("Gateway ARP: solicitud ARP falló (%ld)\n",
                  static_cast<long>(requestError));
  }
  if (resultReady && gatewayArpRequestedIp == currentGatewayIp &&
      currentGatewayNetwork == gatewayArpRequestedNetwork) {
    const String resolvedMac = formatMacAddress(resultMac);
    const bool changed = gatewayMac != resolvedMac ||
                         gatewayMacIp != currentGatewayIp ||
                         gatewayMacNetwork != currentGatewayNetwork;
    gatewayMac = resolvedMac;
    gatewayMacIp = currentGatewayIp;
    gatewayMacNetwork = currentGatewayNetwork;
    nextGatewayArpRequestAt = millis() + 300000UL;
    if (changed) {
      const String manufacturer = ouiManufacturerForMac(gatewayMac);
      Serial.printf("Gateway ARP: %s (%s), titular IEEE: %s\n",
                    gatewayMac.c_str(), gatewayMacIp.c_str(),
                    manufacturer.isEmpty() ? "no encontrado"
                                           : manufacturer.c_str());
      if (!preferencesReady) {
        Serial.println(F("Gateway ARP: MAC obtenida, pero NVS no está disponible"));
      } else if (preferences.putString("gwmac", gatewayMac) == 0 ||
                 preferences.putString("gwip", gatewayMacIp) == 0 ||
                 preferences.putString("gwnet", gatewayMacNetwork) == 0) {
        Serial.println(F("Gateway ARP: no se pudo guardar la MAC en NVS"));
      }
    }
  }

  if (callbackPending || millis() < nextGatewayArpLookupAt) {
    return;
  }

  IP4_ADDR(&gatewayArpTargetIp, gateway[0], gateway[1], gateway[2],
           gateway[3]);
  gatewayArpRequestedIp = currentGatewayIp;
  currentGatewayNetwork.toCharArray(gatewayArpRequestedNetwork,
                                    sizeof(gatewayArpRequestedNetwork));
  const uint32_t now = millis();
  gatewayArpShouldRequest = now >= nextGatewayArpRequestAt;
  if (gatewayArpShouldRequest) {
    nextGatewayArpRequestAt = now + (gatewayMac.isEmpty() ? 10000UL : 300000UL);
  }
  portENTER_CRITICAL(&gatewayArpMux);
  gatewayArpCallbackPending = true;
  portEXIT_CRITICAL(&gatewayArpMux);
  const err_t callbackStatus = tcpip_callback(gatewayArpLookupCallback, nullptr);
  if (callbackStatus != ERR_OK) {
    portENTER_CRITICAL(&gatewayArpMux);
    gatewayArpCallbackPending = false;
    portEXIT_CRITICAL(&gatewayArpMux);
    Serial.printf("Gateway ARP: no se pudo consultar la caché (%d)\n",
                  static_cast<int>(callbackStatus));
    nextGatewayArpLookupAt = millis() + 2000UL;
    return;
  }
  nextGatewayArpLookupAt = millis() + 2000UL;
}

void maintainArpObservations() {
  if (WiFi.status() != WL_CONNECTED) {
    arpObservations.clear();
    portENTER_CRITICAL(&gatewayArpMux);
    arpSnapshotReady = false;
    arpSnapshotCount = 0;
    portEXIT_CRITICAL(&gatewayArpMux);
    return;
  }

  const String currentNetwork = WiFi.SSID() + "|" + WiFi.BSSIDstr();
  const uint32_t now = millis();
  arpObservations.erase(
      std::remove_if(arpObservations.begin(), arpObservations.end(),
                     [now](const ArpObservation &entry) {
                       return now - entry.lastSeenAt > 600000UL;
                     }),
      arpObservations.end());

  ArpSnapshotEntry snapshot[ARP_TABLE_SIZE] = {};
  char snapshotNetwork[sizeof(arpSnapshotNetwork)] = {};
  size_t snapshotCount = 0;
  portENTER_CRITICAL(&gatewayArpMux);
  if (arpSnapshotReady) {
    snapshotCount = arpSnapshotCount;
    memcpy(snapshotNetwork, arpSnapshotNetwork, sizeof(snapshotNetwork));
    for (size_t i = 0; i < snapshotCount; ++i) {
      snapshot[i] = arpSnapshot[i];
    }
    arpSnapshotReady = false;
  }
  portEXIT_CRITICAL(&gatewayArpMux);
  if (snapshotCount == 0 || currentNetwork != snapshotNetwork) {
    return;
  }

  constexpr size_t MAX_ARP_OBSERVATIONS = 64;
  for (size_t i = 0; i < snapshotCount; ++i) {
    const String ip = snapshot[i].ip;
    if (ip.isEmpty()) {
      continue;
    }
    const String mac = formatMacAddress(snapshot[i].mac);
    auto existing = std::find_if(
        arpObservations.begin(), arpObservations.end(),
        [&ip](const ArpObservation &entry) { return entry.ip == ip; });
    if (existing != arpObservations.end()) {
      existing->mac = mac;
      existing->lastSeenAt = now;
      continue;
    }
    if (arpObservations.size() >= MAX_ARP_OBSERVATIONS) {
      const auto oldest = std::min_element(
          arpObservations.begin(), arpObservations.end(),
          [now](const ArpObservation &left, const ArpObservation &right) {
            return now - left.lastSeenAt > now - right.lastSeenAt;
          });
      if (oldest != arpObservations.end()) {
        arpObservations.erase(oldest);
      }
    }
    arpObservations.push_back({ip, mac, now});
  }
}

void startStaConnection(const SavedNetwork &network, bool rememberOnSuccess) {
  pendingNetwork = network;
  rememberPendingNetwork = rememberOnSuccess;
  connectionAttemptActive = true;
  connectionAttemptAt = millis();
  connectionMessage = "Conectando a " + network.ssid;
  lastNetworkError = "";
  WiFi.disconnect(false, false);
  delay(40);
  WiFi.begin(network.ssid.c_str(), network.password.c_str());
}

void maintainStaConnection() {
  if (WiFi.status() == WL_CONNECTED) {
    if (!staWasConnected) {
      staWasConnected = true;
      scheduleOuiUpdate();
    }
    maintainGatewayMac();
    if (connectionAttemptActive && rememberPendingNetwork) {
      if (rememberNetwork(pendingNetwork)) {
        Serial.println(F("Red conectada y guardada en la lista blanca NVS"));
      } else {
        lastNetworkError = "No se pudo guardar la red en NVS";
      }
      rememberPendingNetwork = false;
    }
    connectionAttemptActive = false;
    connectionMessage = "Conectado a " + WiFi.SSID();
    return;
  }

  staWasConnected = false;
  gatewayObservedIp = "";
  nextGatewayArpLookupAt = 0;
  if (connectionAttemptActive) {
    if (millis() - connectionAttemptAt < 20000UL) {
      return;
    }
    connectionAttemptActive = false;
    if (rememberPendingNetwork) {
      lastNetworkError = "No se pudo conectar a " + pendingNetwork.ssid;
    }
    rememberPendingNetwork = false;
    connectionMessage = "STA desconectada";
    nextReconnectAt = millis() + 3000UL;
  }

  if (savedNetworks.empty() || millis() < nextReconnectAt) {
    return;
  }

  const SavedNetwork &network = savedNetworks[reconnectIndex % savedNetworks.size()];
  reconnectIndex = (reconnectIndex + 1) % savedNetworks.size();
  nextReconnectAt = millis() + 25000UL;
  startStaConnection(network, false);
  Serial.printf("Reconexión automática a la red guardada: %s\n",
                network.ssid.c_str());
}

bool scanNearbyNetworks() {
  scanResults.clear();
  Serial.println(F("Iniciando escaneo pasivo Wi-Fi (2.4 GHz)"));
  const int count = WiFi.scanNetworks(false, false, true, 300);
  if (count < 0) {
    Serial.printf("ERROR: escaneo Wi-Fi falló (%d)\n", count);
    return false;
  }

  scanResults.reserve(static_cast<size_t>(count));
  for (int i = 0; i < count; ++i) {
    ScannedNetwork network;
    network.ssid = WiFi.SSID(i);
    network.bssid = WiFi.BSSIDstr(i);
    network.rssi = WiFi.RSSI(i);
    network.channel = static_cast<uint8_t>(WiFi.channel(i));
    network.auth = WiFi.encryptionType(i);
    scanResults.push_back(network);
  }
  WiFi.scanDelete();
  Serial.printf("Escaneo pasivo completado: %u redes\n",
                static_cast<unsigned>(scanResults.size()));
  return true;
}

float channelCrowdingScore(uint8_t candidate) {
  float score = 0;
  for (const ScannedNetwork &network : scanResults) {
    if (network.ssid == AP_SSID) {
      continue;
    }
    const int distance = abs(static_cast<int>(candidate) - network.channel);
    if (distance > 4) {
      continue;
    }
    const float signalWeight =
        std::max(0.0f, std::min(1.0f, (network.rssi + 100.0f) / 70.0f));
    score += (5 - distance) * signalWeight;
  }
  return score;
}

String channelRecommendation() {
  if (scanResults.empty()) {
    return F("Escanea redes para comparar los canales 1, 6 y 11.");
  }

  constexpr uint8_t candidates[] = {1, 6, 11};
  uint8_t bestChannel = candidates[0];
  float bestScore = channelCrowdingScore(bestChannel);
  for (size_t i = 1; i < sizeof(candidates) / sizeof(candidates[0]); ++i) {
    const float score = channelCrowdingScore(candidates[i]);
    if (score < bestScore) {
      bestScore = score;
      bestChannel = candidates[i];
    }
  }

  String advice = "Canal sugerido: ";
  advice += String(bestChannel);
  advice += " · solapamiento relativo ";
  advice += String(bestScore, 1);
  advice += ". Cámbialo manualmente en el router y vuelve a medir.";
  return advice;
}

String statusJson() {
  const bool staConnected = WiFi.status() == WL_CONNECTED;
  const String currentGatewayIp =
      staConnected ? WiFi.gatewayIP().toString() : String();
  const String currentGatewayNetwork =
      staConnected ? WiFi.SSID() + "|" + WiFi.BSSIDstr() : String();
  const String currentGatewayMac =
      staConnected && gatewayMacIp == currentGatewayIp &&
              gatewayMacNetwork == currentGatewayNetwork
          ? gatewayMac
          : String();
  const bool ouiLAvailable = ouiDatabaseAvailable(OUI_DATABASES[0]);
  const bool ouiMAvailable = ouiDatabaseAvailable(OUI_DATABASES[1]);
  const bool ouiSAvailable = ouiDatabaseAvailable(OUI_DATABASES[2]);
  String body;
  body.reserve(256 + savedNetworks.size() * 40);
  body = F("{\"apSsid\":\"");
  body += AP_SSID;
  body += F("\",\"apIp\":\"");
  body += WiFi.softAPIP().toString();
  body += F("\",\"apClients\":");
  body += String(WiFi.softAPgetStationNum());
  body += F(",\"staConnected\":");
  body += WiFi.status() == WL_CONNECTED ? F("true") : F("false");
  body += F(",\"staSsid\":\"");
  if (WiFi.status() == WL_CONNECTED) {
    body += jsonEscape(WiFi.SSID());
  }
  body += F("\",\"staIp\":\"");
  if (WiFi.status() == WL_CONNECTED) {
    body += WiFi.localIP().toString();
  }
  body += F("\",\"staGateway\":\"");
  if (WiFi.status() == WL_CONNECTED) {
    body += WiFi.gatewayIP().toString();
  }
  body += F("\",\"staGatewayMac\":\"");
  body += jsonEscape(currentGatewayMac);
  body += F("\",\"staGatewayManufacturer\":\"");
  if (!currentGatewayMac.isEmpty()) {
    body += jsonEscape(ouiManufacturerForMac(currentGatewayMac));
  }
  body += F("\",\"rssi\":");
  body += WiFi.status() == WL_CONNECTED ? String(WiFi.RSSI()) : F("null");
  body += F(",\"channel\":");
  body += WiFi.status() == WL_CONNECTED ? String(WiFi.channel()) : F("null");
  body += F(",\"bleProvisioningActive\":");
  body += bleProvisioningActive ? F("true") : F("false");
  body += F(",\"bleServiceName\":\"");
  body += jsonEscape(bleServiceName);
  body += F("\",\"blePop\":\"");
  body += bleProvisioningActive ? bleProofOfPossession : "";
  body += '"';
  body += F(",\"message\":\"");
  body += jsonEscape(connectionMessage);
  body += F("\",\"error\":\"");
  body += jsonEscape(lastNetworkError);
  body += F("\",\"channelAdvice\":\"");
  body += jsonEscape(channelRecommendation());
  body += F("\",\"filesystemReady\":");
  body += filesystemReady ? F("true") : F("false");
  body += F(",\"sdReady\":");
  body += sdCardReady ? F("true") : F("false");
  body += F(",\"sdMessage\":\"");
  body += jsonEscape(sdLastMessage);
  body += '"';
  body += F(",\"sdFormatRunning\":");
  body += sdFormatRunning ? F("true") : F("false");
  body += F(",\"sdFormatAttempted\":");
  body += sdFormatAttempted ? F("true") : F("false");
  body += F(",\"sdFormatSucceeded\":");
  body += sdFormatSucceeded ? F("true") : F("false");
  body += F(",\"ouiStorage\":\"");
  body += sdCardReady && ouiStorageOnSd ? F("microSD") : F("LittleFS");
  body += F("\",\"ouiLAvailable\":");
  body += ouiLAvailable ? F("true") : F("false");
  body += F(",\"ouiMAvailable\":");
  body += ouiMAvailable ? F("true") : F("false");
  body += F(",\"ouiSAvailable\":");
  body += ouiSAvailable ? F("true") : F("false");
  body += F(",\"ouiAvailable\":");
  body += ouiLAvailable && ouiMAvailable && ouiSAvailable ? F("true")
                                                         : F("false");
  body += F(",\"ouiUpdateRunning\":");
  body += ouiUpdateRunning ? F("true") : F("false");
  body += F(",\"ouiUpdateAttempted\":");
  body += ouiUpdateAttempted ? F("true") : F("false");
  body += F(",\"ouiUpdateSucceeded\":");
  body += ouiUpdateSucceeded ? F("true") : F("false");
  body += F(",\"ouiUploadRunning\":");
  body += ouiUploadRunning ? F("true") : F("false");
  body += F(",\"filesystemTotalMb\":");
  body += filesystemReady
              ? String(static_cast<double>(LittleFS.totalBytes()) / 1048576.0,
                       1)
              : F("0");
  body += F(",\"filesystemUsedMb\":");
  body += filesystemReady
              ? String(static_cast<double>(LittleFS.usedBytes()) / 1048576.0,
                       1)
              : F("0");
  body += F(",\"sdTotalMb\":");
  body += sdCardReady
              ? String(static_cast<double>(SD_MMC.totalBytes()) / 1048576.0, 1)
              : F("0");
  body += F(",\"sdUsedMb\":");
  body += sdCardReady
              ? String(static_cast<double>(SD_MMC.usedBytes()) / 1048576.0, 1)
              : F("0");
  body += F(",\"whitelist\":[");
  for (size_t i = 0; i < savedNetworks.size(); ++i) {
    if (i != 0) {
      body += ',';
    }
    body += '"';
    body += jsonEscape(savedNetworks[i].ssid);
    body += '"';
  }
  body += F("]}");
  return body;
}

bool parseFloatArgument(const String &input, float &value) {
  if (input.isEmpty()) {
    return false;
  }
  char *end = nullptr;
  const float parsed = strtof(input.c_str(), &end);
  if (end == input.c_str() || *end != '\0' || !std::isfinite(parsed)) {
    return false;
  }
  value = parsed;
  return true;
}

PointAnalysis analyzePoint(const SurveyPoint &point,
                           const SurveyPoint *previous) {
  const auto percent = [](float value) {
    return std::max(0.0f, std::min(100.0f, value));
  };
  const bool hasRssi = point.rssi < 0;
  const float signalScore =
      hasRssi ? percent((point.rssi + 90.0f) * (100.0f / 35.0f)) : 50.0f;
  const float throughputScore = percent(point.mbps * 20.0f);
  const float latencyScore = percent(100.0f - (point.latencyMs - 20.0f) *
                                                   (100.0f / 130.0f));
  PointAnalysis analysis;
  analysis.score = static_cast<uint8_t>(
      lroundf(signalScore * 0.45f + throughputScore * 0.35f +
              latencyScore * 0.20f));

  if (previous != nullptr) {
    if (previous->mbps >= 1.0f && point.mbps < previous->mbps * 0.70f) {
      analysis.anomaly = F("velocidad cayó más del 30%");
    }
    if (hasRssi && previous->rssi < 0 && point.rssi <= previous->rssi - 10) {
      if (!analysis.anomaly.isEmpty()) {
        analysis.anomaly += F("; ");
      }
      analysis.anomaly += F("RSSI cayó 10 dB o más");
    }
    if (point.latencyMs > previous->latencyMs * 2.0f &&
        point.latencyMs > previous->latencyMs + 20.0f) {
      if (!analysis.anomaly.isEmpty()) {
        analysis.anomaly += F("; ");
      }
      analysis.anomaly += F("latencia aumentó más del doble");
    }
  }

  if (!analysis.anomaly.isEmpty()) {
    analysis.quality = F("Inestable");
    analysis.recommendation =
        "Cambio detectado frente a la medición anterior: " + analysis.anomaly +
        ". Repite la prueba y revisa obstáculos o carga de red.";
  } else if (analysis.score >= 80) {
    analysis.quality = F("Buena");
    analysis.recommendation =
        F("Buen resultado inicial; valida con el flujo real de la cámara.");
  } else if (analysis.score >= 60) {
    analysis.quality = F("Aceptable");
    analysis.recommendation =
        F("Hay margen de mejora; compara otro punto o canal.");
  } else {
    analysis.quality = F("Débil");
    if (hasRssi && point.rssi < -75) {
      analysis.recommendation =
          F("Señal baja: acerca el punto al router o reduce obstáculos.");
    } else if (point.mbps < 5.0f) {
      analysis.recommendation =
          F("Rendimiento bajo frente a la referencia de 5 Mbps; repite la prueba.");
    } else {
      analysis.recommendation =
          F("Latencia alta: revisa congestión y vuelve a medir.");
    }
  }
  return analysis;
}

bool parsePointCsvLine(String line, SurveyPoint &point) {
  line.trim();
  if (line.isEmpty() || line.startsWith("uptime_ms")) {
    return false;
  }

  String fields[6];
  size_t fieldIndex = 0;
  int start = 0;
  for (size_t i = 0; i <= line.length(); ++i) {
    if (i == line.length() || line[i] == ',') {
      if (fieldIndex == 6) {
        return false;
      }
      fields[fieldIndex++] = line.substring(start, i);
      start = static_cast<int>(i + 1);
    }
  }
  if (fieldIndex != 6 || fields[0].isEmpty() || fields[1].isEmpty() ||
      fields[3].isEmpty() || fields[4].isEmpty()) {
    return false;
  }

  char *end = nullptr;
  const unsigned long long uptime = strtoull(fields[0].c_str(), &end, 10);
  if (end == fields[0].c_str() || *end != '\0' || fields[0][0] == '-' ||
      uptime > UINT32_MAX) {
    return false;
  }
  point.uptimeMs = static_cast<uint32_t>(uptime);
  point.name = fields[1];
  float mbps = 0;
  float latencyMs = 0;
  if (!parseFloatArgument(fields[2], mbps) ||
      !parseFloatArgument(fields[5], latencyMs) || mbps < 0 ||
      mbps > 10000 || latencyMs < 0 || latencyMs > 120000) {
    return false;
  }

  end = nullptr;
  const long rssi = strtol(fields[3].c_str(), &end, 10);
  if (end == fields[3].c_str() || *end != '\0' || rssi < -127 || rssi > 0) {
    return false;
  }
  end = nullptr;
  const long channel = strtol(fields[4].c_str(), &end, 10);
  if (end == fields[4].c_str() || *end != '\0' || channel < 0 ||
      channel > UINT8_MAX) {
    return false;
  }

  point.mbps = mbps;
  point.rssi = static_cast<int32_t>(rssi);
  point.channel = static_cast<uint8_t>(channel);
  point.latencyMs = latencyMs;
  return true;
}

bool findPreviousPoint(const String &name, SurveyPoint &previous) {
  if (!filesystemReady || !LittleFS.exists(POINTS_FILE)) {
    return false;
  }
  File file = LittleFS.open(POINTS_FILE, FILE_READ);
  if (!file) {
    Serial.println(F("ERROR: no se pudo leer el historial para detectar cambios"));
    return false;
  }
  bool found = false;
  while (file.available()) {
    SurveyPoint candidate;
    if (parsePointCsvLine(file.readStringUntil('\n'), candidate) &&
        candidate.name == name) {
      previous = candidate;
      found = true;
    }
  }
  file.close();
  return found;
}

String sanitizePointName(String name) {
  name.trim();
  String sanitized;
  sanitized.reserve(name.length());
  for (size_t i = 0; i < name.length() && sanitized.length() < 32; ++i) {
    const char c = name[i];
    const bool valid =
        (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == '_' || c == '-' || c == ' ';
    sanitized += valid ? c : '_';
  }
  sanitized.trim();
  return sanitized;
}

bool appendSurveyPoint(const SurveyPoint &point) {
  if (!filesystemReady) {
    return false;
  }

  const bool needsHeader = !LittleFS.exists(POINTS_FILE);
  File file = LittleFS.open(POINTS_FILE, FILE_APPEND);
  if (!file) {
    Serial.println(F("ERROR: no se pudo abrir points.csv para escritura"));
    return false;
  }
  if (needsHeader) {
    file.println(F("uptime_ms,name,mbps,rssi_dbm,channel,latency_ms"));
  }
  char line[128];
  const int lineLength =
      snprintf(line, sizeof(line), "%lu,%s,%.3f,%ld,%u,%.2f\n",
               static_cast<unsigned long>(point.uptimeMs), point.name.c_str(),
               point.mbps, static_cast<long>(point.rssi), point.channel,
               point.latencyMs);
  if (lineLength < 0 || static_cast<size_t>(lineLength) >= sizeof(line)) {
    file.close();
    Serial.println(F("ERROR: la fila CSV excede el tamaño permitido"));
    return false;
  }
  const size_t written =
      file.write(reinterpret_cast<const uint8_t *>(line),
                 static_cast<size_t>(lineLength));
  file.close();
  if (written != static_cast<size_t>(lineLength)) {
    Serial.println(F("ERROR: no se pudo escribir el punto de medición"));
    return false;
  }
  return true;
}

bool pointsJson(String &body) {
  body = '[';
  if (!filesystemReady) {
    return false;
  }
  if (!LittleFS.exists(POINTS_FILE)) {
    body += ']';
    return true;
  }

  File file = LittleFS.open(POINTS_FILE, FILE_READ);
  if (!file) {
    Serial.println(F("ERROR: no se pudo abrir points.csv para lectura"));
    return false;
  }

  const size_t csvBytes = file.size();
  const size_t estimatedJsonBytes = csvBytes * 8 + 2;
  if (!body.reserve(estimatedJsonBytes)) {
    Serial.printf("ERROR: no hay memoria para preparar JSON de puntos (%u bytes)\n",
                  static_cast<unsigned>(estimatedJsonBytes));
    file.close();
    return false;
  }

  std::vector<SurveyPoint> latestByName;
  bool first = true;
  while (file.available()) {
    SurveyPoint point;
    if (!parsePointCsvLine(file.readStringUntil('\n'), point)) {
      continue;
    }

    const SurveyPoint *previous = nullptr;
    size_t previousIndex = latestByName.size();
    for (size_t i = 0; i < latestByName.size(); ++i) {
      if (latestByName[i].name == point.name) {
        previous = &latestByName[i];
        previousIndex = i;
        break;
      }
    }
    const PointAnalysis analysis = analyzePoint(point, previous);

    if (!first) {
      body += ',';
    }
    first = false;
    body += F("{\"uptimeMs\":");
    body += String(point.uptimeMs);
    body += F(",\"name\":\"");
    body += jsonEscape(point.name);
    body += F("\",\"mbps\":");
    body += String(point.mbps, 3);
    body += F(",\"rssi\":");
    body += String(point.rssi);
    body += F(",\"channel\":");
    body += String(point.channel);
    body += F(",\"latencyMs\":");
    body += String(point.latencyMs, 2);
    body += F(",\"score\":");
    body += String(analysis.score);
    body += F(",\"quality\":\"");
    body += jsonEscape(analysis.quality);
    body += F("\",\"recommendation\":\"");
    body += jsonEscape(analysis.recommendation);
    body += F("\",\"anomaly\":\"");
    body += jsonEscape(analysis.anomaly.isEmpty() ? String("Sin anomalía")
                                                  : analysis.anomaly);
    body += '"';
    body += '}';

    if (previousIndex < latestByName.size()) {
      latestByName[previousIndex] = point;
    } else {
      latestByName.push_back(point);
    }
    latestPointName = point.name;
    latestAnalysis = analysis;
  }
  file.close();
  body += ']';
  Serial.printf("[Portal] Puntos JSON: %u bytes; CSV: %u bytes\n",
                static_cast<unsigned>(body.length()),
                static_cast<unsigned>(csvBytes));
  return true;
}

String sanitizeAssetValue(String value, size_t maxLength) {
  value.trim();
  String clean;
  clean.reserve(std::min(value.length(), maxLength));
  for (size_t i = 0; i < value.length() && clean.length() < maxLength; ++i) {
    const char c = value[i];
    const bool valid =
        (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == ' ' || c == '-' || c == '_' ||
        c == '.' || c == '/' || c == '+' || c == '(' || c == ')';
    clean += valid ? c : '_';
  }
  clean.trim();
  return clean;
}

bool normalizeMacAddress(String input, String &normalized) {
  input.trim();
  String hex;
  hex.reserve(12);
  for (size_t i = 0; i < input.length(); ++i) {
    const char c = input[i];
    if (c == ':' || c == '-') {
      continue;
    }
    const bool isHex = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') ||
                       (c >= 'A' && c <= 'F');
    if (!isHex || hex.length() == 12) {
      return false;
    }
    hex += static_cast<char>(toupper(static_cast<unsigned char>(c)));
  }
  if (hex.length() != 12) {
    return false;
  }
  normalized = "";
  normalized.reserve(17);
  for (size_t i = 0; i < hex.length(); ++i) {
    if (i != 0 && i % 2 == 0) {
      normalized += ':';
    }
    normalized += hex[i];
  }
  return true;
}

bool isCctvAssetType(const String &type) {
  return type == "Camara" || type == "NVR" || type == "DVR" ||
         type == "Otro";
}

bool parseCctvAssetCsvLine(String line, CctvAsset &asset) {
  line.trim();
  if (line.isEmpty() || line.startsWith("ip,")) {
    return false;
  }

  String fields[7];
  size_t fieldIndex = 0;
  int start = 0;
  for (size_t i = 0; i <= line.length(); ++i) {
    if (i == line.length() || line[i] == ',') {
      if (fieldIndex == 7) {
        return false;
      }
      fields[fieldIndex++] = line.substring(start, i);
      start = static_cast<int>(i + 1);
    }
  }
  if (fieldIndex != 7 || fields[0].isEmpty() || fields[1].isEmpty() ||
      fields[2].isEmpty() || fields[3].isEmpty()) {
    return false;
  }

  IPAddress parsedIp;
  String normalizedMac;
  if (!parsedIp.fromString(fields[0]) ||
      !normalizeMacAddress(fields[3], normalizedMac) ||
      !isCctvAssetType(fields[2])) {
    return false;
  }

  asset.ip = parsedIp.toString();
  asset.name = fields[1];
  asset.type = fields[2];
  asset.mac = normalizedMac;
  asset.manufacturer = fields[4];
  asset.model = fields[5];
  asset.firmware = fields[6];
  return true;
}

bool loadCctvAssets() {
  cctvAssets.clear();
  if (!filesystemReady || !LittleFS.exists(CCTV_ASSETS_FILE)) {
    return filesystemReady;
  }

  File file = LittleFS.open(CCTV_ASSETS_FILE, FILE_READ);
  if (!file) {
    Serial.println(F("ERROR: no se pudo abrir el inventario CCTV"));
    return false;
  }
  while (file.available()) {
    CctvAsset asset;
    if (parseCctvAssetCsvLine(file.readStringUntil('\n'), asset)) {
      cctvAssets.push_back(asset);
    }
  }
  file.close();
  Serial.printf("Inventario CCTV cargado: %u equipos\n",
                static_cast<unsigned>(cctvAssets.size()));
  return true;
}

String cctvAssetsJson() {
  String body;
  body.reserve(128 + cctvAssets.size() * 180);
  body = '[';
  for (size_t i = 0; i < cctvAssets.size(); ++i) {
    if (i != 0) {
      body += ',';
    }
    const CctvAsset &asset = cctvAssets[i];
    body += F("{\"ip\":\"");
    body += jsonEscape(asset.ip);
    body += F("\",\"name\":\"");
    body += jsonEscape(asset.name);
    body += F("\",\"type\":\"");
    body += jsonEscape(asset.type);
    body += F("\",\"mac\":\"");
    body += jsonEscape(asset.mac);
    body += F("\",\"manufacturer\":\"");
    body += jsonEscape(asset.manufacturer);
    body += F("\",\"ouiManufacturer\":\"");
    body += jsonEscape(ouiManufacturerForMac(asset.mac));
    body += F("\",\"model\":\"");
    body += jsonEscape(asset.model);
    body += F("\",\"firmware\":\"");
    body += jsonEscape(asset.firmware);
    body += F("\",\"networkName\":\"");
    body += jsonEscape(WiFi.status() == WL_CONNECTED ? WiFi.SSID() : String(""));
    body += F("\"}");
  }
  body += ']';
  return body;
}

String arpNeighborsJson() {
  String body;
  body.reserve(128 + arpObservations.size() * 120);
  body = '[';
  for (size_t i = 0; i < arpObservations.size(); ++i) {
    if (i != 0) {
      body += ',';
    }
    const ArpObservation &entry = arpObservations[i];
    body += F("{\"ip\":\"");
    body += jsonEscape(entry.ip);
    body += F("\",\"mac\":\"");
    body += jsonEscape(entry.mac);
    body += F("\",\"manufacturer\":\"");
    body += jsonEscape(ouiManufacturerForMac(entry.mac));
    body += F("\",\"lastSeenSeconds\":");
    body += String((millis() - entry.lastSeenAt) / 1000UL);
    body += '}';
  }
  body += ']';
  return body;
}

bool appendCctvAsset(const CctvAsset &asset) {
  const bool needsHeader = !LittleFS.exists(CCTV_ASSETS_FILE);
  File file = LittleFS.open(CCTV_ASSETS_FILE, FILE_APPEND);
  if (!file) {
    Serial.println(F("ERROR: no se pudo abrir el inventario CCTV para escritura"));
    return false;
  }
  if (needsHeader) {
    file.println(F("ip,name,type,mac,manufacturer,model,firmware"));
  }
  char line[256];
  const int lineLength =
      snprintf(line, sizeof(line), "%s,%s,%s,%s,%s,%s,%s\n", asset.ip.c_str(),
               asset.name.c_str(), asset.type.c_str(), asset.mac.c_str(),
               asset.manufacturer.c_str(), asset.model.c_str(),
               asset.firmware.c_str());
  if (lineLength < 0 || static_cast<size_t>(lineLength) >= sizeof(line)) {
    file.close();
    Serial.println(F("ERROR: el registro CCTV excede el tamaño permitido"));
    return false;
  }
  const size_t written =
      file.write(reinterpret_cast<const uint8_t *>(line),
                 static_cast<size_t>(lineLength));
  file.close();
  if (written != static_cast<size_t>(lineLength)) {
    Serial.println(F("ERROR: no se pudo escribir el registro CCTV completo"));
    return false;
  }
  return true;
}

void updateDisplay() {
  if (!displayReady || bootQrScreen != BootQrScreen::Status) {
    return;
  }

  display->fillScreen(RGB565_BLACK);
  display->setTextWrap(false);
  display->setTextSize(1);
  display->setTextColor(RGB565_WHITE);
  display->setCursor(5, 6);
  display->println(F("ESP32 SITE SURVEY"));
  display->drawFastHLine(5, 19, 162, RGB565_CYAN);

  display->setCursor(5, 27);
  display->setTextColor(RGB565_GREEN);
  display->println(accessPointReady ? F("AP: ACTIVO") : F("AP: ERROR"));
  display->setTextColor(RGB565_WHITE);
  display->setCursor(5, 42);
  display->printf("SSID: %s", AP_SSID);
  display->setCursor(5, 57);
  display->printf("IP: %s", WiFi.softAPIP().toString().c_str());
  display->setCursor(5, 72);
  display->printf("Clientes AP: %u",
                  static_cast<unsigned>(WiFi.softAPgetStationNum()));
  display->drawFastHLine(5, 91, 162, RGB565_DARKGREY);

  display->setCursor(5, 101);
  display->setTextColor(WiFi.status() == WL_CONNECTED ? RGB565_GREEN
                                                      : RGB565_YELLOW);
  display->println(WiFi.status() == WL_CONNECTED ? F("STA: CONECTADA")
                                                 : F("STA: SIN CONEXION"));
  display->setTextColor(RGB565_WHITE);
  display->setCursor(5, 117);
  String staSsid =
      WiFi.status() == WL_CONNECTED ? WiFi.SSID() : connectionMessage;
  if (staSsid.length() > 25) {
    staSsid = staSsid.substring(0, 25);
  }
  display->printf("Red: %s", staSsid.c_str());
  display->setCursor(5, 132);
  if (WiFi.status() == WL_CONNECTED) {
    display->printf("RSSI: %d dBm", WiFi.RSSI());
  } else {
    display->println(F("RSSI: --"));
  }
  display->setCursor(5, 147);
  if (WiFi.status() == WL_CONNECTED) {
    display->printf("STA IP: %s", WiFi.localIP().toString().c_str());
  } else {
    display->println(F("STA IP: --"));
  }
  display->drawFastHLine(5, 166, 162, RGB565_DARKGREY);

  display->setCursor(5, 176);
  display->setTextColor(RGB565_CYAN);
  display->println(F("PORTAL LOCAL"));
  display->setTextColor(RGB565_WHITE);
  display->setCursor(5, 192);
  display->println(F("http://192.168.4.1"));
  display->setCursor(5, 210);
  display->printf("Redes guardadas: %u",
                  static_cast<unsigned>(savedNetworks.size()));
  display->setCursor(5, 230);
  display->printf("Puntos: %s",
                  filesystemReady && LittleFS.exists(POINTS_FILE) ? "LittleFS"
                                                                  : "0");
  display->drawFastHLine(5, 250, 162, RGB565_DARKGREY);
  display->setTextColor(RGB565_ORANGE);
  display->setCursor(5, 261);
  if (bleProvisioningActive) {
    display->printf("BLE: %s", bleServiceName);
  } else {
    display->println(F("Escaneo PASIVO 2.4 GHz"));
  }
  display->setTextColor(RGB565_LIGHTGREY);
  display->setCursor(5, 278);
  if (bleProvisioningActive) {
    display->printf("PIN BLE: %s", bleProofOfPossession);
  } else {
    display->println(F("Solo redes autorizadas"));
  }
  display->setCursor(5, 295);
  if (latestPointName.isEmpty()) {
    display->setTextColor(RGB565_LIGHTGREY);
    display->println(F("Analisis local: sin datos"));
  } else {
    display->setTextColor(latestAnalysis.quality == "Buena" ? RGB565_GREEN
                                                            : RGB565_YELLOW);
    display->printf("Analisis: %u/100 %s",
                    static_cast<unsigned>(latestAnalysis.score),
                    latestAnalysis.quality.c_str());
    display->setCursor(5, 309);
    display->setTextColor(RGB565_WHITE);
    display->printf("Punto: %s", latestPointName.c_str());
  }
}

int provisioningQrBottom = 34;

void drawQrModules(esp_qrcode_handle_t qrCode) {
  const int qrSize = esp_qrcode_get_size(qrCode);
  constexpr int quietZone = 4;
  const int scale =
      std::max(1, std::min(3, (SCREEN_WIDTH - 12) / (qrSize + quietZone * 2)));
  const int totalSize = (qrSize + quietZone * 2) * scale;
  const int left = (SCREEN_WIDTH - totalSize) / 2;
  constexpr int top = 34;

  display->fillRect(left, top, totalSize, totalSize, RGB565_WHITE);
  for (int y = 0; y < qrSize; ++y) {
    int runStart = -1;
    for (int x = 0; x <= qrSize; ++x) {
      const bool dark = x < qrSize && esp_qrcode_get_module(qrCode, x, y);
      if (dark && runStart < 0) {
        runStart = x;
      } else if (!dark && runStart >= 0) {
        display->fillRect(left + (runStart + quietZone) * scale,
                          top + (y + quietZone) * scale,
                          (x - runStart) * scale, scale, RGB565_BLACK);
        runStart = -1;
      }
    }
  }
  provisioningQrBottom = top + totalSize;
}

void showProvisioningQrScreen() {
  display->fillScreen(RGB565_WHITE);
  display->setTextWrap(false);
  display->setTextColor(RGB565_BLACK);
  display->setTextSize(1);
  display->setCursor(8, 5);
  display->println(F("CONFIGURAR POR BLE"));
  display->setCursor(8, 19);
  display->println(F("Escanea con la app Espressif"));

  const String payload =
      String("{\"ver\":\"v1\",\"name\":\"") + bleServiceName +
      "\",\"pop\":\"" + bleProofOfPossession + "\",\"transport\":\"ble\"}";
  esp_qrcode_config_t qrConfig = ESP_QRCODE_CONFIG_DEFAULT();
  qrConfig.display_func = drawQrModules;
  qrConfig.max_qrcode_version = 6;
  const esp_err_t result = esp_qrcode_generate(&qrConfig, payload.c_str());

  display->setTextSize(1);
  display->setCursor(8, provisioningQrBottom + 6);
  if (result != ESP_OK) {
    display->println(F("No se pudo generar QR"));
  } else {
    display->printf("Equipo: %s", bleServiceName);
  }
  display->setTextSize(2);
  display->setCursor(8, provisioningQrBottom + 22);
  display->printf("PIN: %s", bleProofOfPossession);
  display->setTextSize(1);
  display->setCursor(8, provisioningQrBottom + 46);
  display->println(F("BOOT: QR de acceso STA"));
}

void showStaPortalQrScreen() {
  display->fillScreen(RGB565_WHITE);
  display->setTextWrap(false);
  display->setTextColor(RGB565_BLACK);
  display->setTextSize(1);
  display->setCursor(8, 5);
  display->println(F("ABRIR PORTAL STA"));
  display->setCursor(8, 19);
  display->println(F("Escanea para abrir navegador"));

  if (WiFi.status() != WL_CONNECTED) {
    display->setCursor(8, 52);
    display->println(F("STA sin conexion."));
    display->setCursor(8, 70);
    display->println(F("Configura Wi-Fi con el"));
    display->setCursor(8, 84);
    display->println(F("QR anterior y vuelve aqui."));
    display->setCursor(8, 112);
    display->println(F("BOOT: volver al estado"));
    return;
  }

  String url = F("http://");
  url += WiFi.localIP().toString();
  url += '/';

  esp_qrcode_config_t qrConfig = ESP_QRCODE_CONFIG_DEFAULT();
  qrConfig.display_func = drawQrModules;
  qrConfig.max_qrcode_version = 6;
  provisioningQrBottom = 34;
  const esp_err_t result = esp_qrcode_generate(&qrConfig, url.c_str());

  display->setTextSize(1);
  display->setCursor(8, provisioningQrBottom + 6);
  if (result != ESP_OK) {
    display->println(F("No se pudo generar QR"));
  } else {
    display->println(url);
  }
  display->setCursor(8, provisioningQrBottom + 24);
  display->println(F("BOOT: volver al estado"));
}

void showSdCardScreen() {
  display->fillScreen(RGB565_BLACK);
  display->setTextWrap(false);
  display->setTextColor(RGB565_CYAN);
  display->setTextSize(1);
  display->setCursor(8, 8);
  display->println(F("ESTADO MICROSD"));
  display->drawFastHLine(8, 23, 156, RGB565_DARKGREY);
  display->setCursor(8, 38);
  display->setTextColor(sdCardReady ? RGB565_GREEN : RGB565_YELLOW);
  display->println(sdCardReady ? F("Estado: MONTADA") : F("Estado: NO MONTADA"));
  display->setTextColor(RGB565_WHITE);
  display->setCursor(8, 58);
  if (sdCardReady) {
    display->printf("Tamano: %llu MB",
                    static_cast<unsigned long long>(SD_MMC.cardSize() /
                                                    (1024ULL * 1024ULL)));
    display->setCursor(8, 74);
    display->printf("Usados: %llu MB",
                    static_cast<unsigned long long>(SD_MMC.usedBytes() /
                                                    (1024ULL * 1024ULL)));
  } else {
    display->println(F("Inserta la tarjeta y reinicia"));
    display->setCursor(8, 74);
    display->println(F("si no aparece detectada."));
    display->setCursor(8, 94);
    display->println(sdLastMessage.substring(0, 25));
  }
  display->setCursor(8, 132);
  display->setTextColor(RGB565_ORANGE);
  display->println(F("BOOT para volver al estado"));
}

bool formatAndMountSdCard() {
  sdCardReady = false;
  ouiStorageOnSd = false;
  SD_MMC.end();
  if (!SD_MMC.setPins(PIN_SD_CLK, PIN_SD_CMD, PIN_SD_D0)) {
    sdLastMessage = "No se pudieron configurar pines SDMMC";
    Serial.println(sdLastMessage);
    return false;
  }

  sdmmc_host_t host = SDMMC_HOST_DEFAULT();
  host.flags = SDMMC_HOST_FLAG_1BIT;
  host.max_freq_khz = SDMMC_FREQ_PROBING;

  sdmmc_slot_config_t slot = SDMMC_SLOT_CONFIG_DEFAULT();
  slot.clk = static_cast<gpio_num_t>(PIN_SD_CLK);
  slot.cmd = static_cast<gpio_num_t>(PIN_SD_CMD);
  slot.d0 = static_cast<gpio_num_t>(PIN_SD_D0);
  slot.d1 = GPIO_NUM_NC;
  slot.d2 = GPIO_NUM_NC;
  slot.d3 = GPIO_NUM_NC;
  slot.width = 1;
  slot.flags |= SDMMC_SLOT_FLAG_INTERNAL_PULLUP;

  esp_vfs_fat_mount_config_t mountConfig = {
      .format_if_mount_failed = true,
      .max_files = 2,
      .allocation_unit_size = 0,
      .disk_status_check_enable = false,
      .use_one_fat = false,
  };
  sdmmc_card_t *card = nullptr;
  const esp_err_t mountResult =
      esp_vfs_fat_sdmmc_mount("/sdcard", &host, &slot, &mountConfig, &card);
  if (mountResult != ESP_OK) {
    sdLastMessage = String("Inicializacion SD: ") + esp_err_to_name(mountResult);
    Serial.printf("ERROR: %s (0x%x)\n", sdLastMessage.c_str(),
                  static_cast<unsigned>(mountResult));
    if (mountResult == ESP_ERR_INVALID_RESPONSE) {
      Serial.println(F("La tarjeta no respondio al bus SDMMC; no se puede formatear."));
    }
    return false;
  }

  Serial.printf("MicroSD detectada: %llu MB; formateando FAT\n",
                static_cast<unsigned long long>(card->csd.capacity) /
                    (1024ULL * 1024ULL));
  const esp_err_t formatResult = esp_vfs_fat_sdcard_format("/sdcard", card);
  const esp_err_t unmountResult = esp_vfs_fat_sdcard_unmount("/sdcard", card);
  if (formatResult != ESP_OK) {
    sdLastMessage = String("Formato FAT: ") + esp_err_to_name(formatResult);
    Serial.printf("ERROR: %s (0x%x)\n", sdLastMessage.c_str(),
                  static_cast<unsigned>(formatResult));
    return false;
  }
  if (unmountResult != ESP_OK) {
    sdLastMessage = String("Desmontaje: ") + esp_err_to_name(unmountResult);
    Serial.printf("ERROR: %s (0x%x)\n", sdLastMessage.c_str(),
                  static_cast<unsigned>(unmountResult));
    return false;
  }

  if (!SD_MMC.setPins(PIN_SD_CLK, PIN_SD_CMD, PIN_SD_D0) ||
      !SD_MMC.begin("/sdcard", true, false, SDMMC_FREQ_PROBING) ||
      SD_MMC.cardType() == CARD_NONE) {
    sdLastMessage = "FAT creado, pero no se pudo montar";
    Serial.println(sdLastMessage);
    SD_MMC.end();
    return false;
  }

  sdCardReady = true;
  ouiStorageOnSd = true;
  if (!SD_MMC.exists(OUI_DIRECTORY) && !SD_MMC.mkdir(OUI_DIRECTORY)) {
    Serial.println(F("AVISO: no se pudo crear /ieee en la microSD"));
  }
  sdLastMessage = "FAT formateada; microSD montada";
  Serial.println(sdLastMessage);
  return true;
}

void sdFormatTask(void *) {
  sdFormatSucceeded = formatAndMountSdCard();
  sdFormatRunning = false;
  vTaskDelete(nullptr);
}

bool startSdFormatTask() {
  if (sdFormatRunning || ouiUpdateRunning) {
    return false;
  }
  sdFormatSucceeded = false;
  sdFormatAttempted = true;
  sdLastMessage = "Formateando microSD";
  sdFormatRunning = true;
  if (xTaskCreatePinnedToCore(sdFormatTask, "sd-format", 12288, nullptr, 1,
                              nullptr, 1) != pdPASS) {
    sdFormatRunning = false;
    sdLastMessage = "No se pudo iniciar la tarea de formato";
    return false;
  }
  return true;
}

void handleBootButton() {
  static bool lastReading = HIGH;
  static bool stableReading = HIGH;
  static uint32_t lastChangeAt = 0;
  static uint32_t pressStartedAt = 0;
  static constexpr uint32_t LONG_PRESS_MS = 900;
  const bool reading = digitalRead(PIN_BOOT);
  if (reading != lastReading) {
    lastReading = reading;
    lastChangeAt = millis();
  }
  if (millis() - lastChangeAt < 40 || reading == stableReading) {
    return;
  }
  stableReading = reading;
  if (stableReading == LOW) {
    pressStartedAt = millis();
    return;
  }

  const bool longPress = millis() - pressStartedAt >= LONG_PRESS_MS;
  if (longPress) {
    if (bootQrScreen == BootQrScreen::SdCard) {
      bootQrScreen = BootQrScreen::Status;
      updateDisplay();
    } else {
      bootQrScreen = BootQrScreen::SdCard;
      showSdCardScreen();
    }
    return;
  }

  switch (bootQrScreen) {
  case BootQrScreen::Status:
    bootQrScreen = BootQrScreen::WifiProvisioning;
    startBleProvisioning(true);
    showProvisioningQrScreen();
    break;
  case BootQrScreen::WifiProvisioning:
    bootQrScreen = BootQrScreen::StaPortal;
    showStaPortalQrScreen();
    break;
  case BootQrScreen::StaPortal:
    bootQrScreen = BootQrScreen::Status;
    updateDisplay();
    break;
  case BootQrScreen::SdCard:
    bootQrScreen = BootQrScreen::Status;
    updateDisplay();
    break;
  }
}

void handleScan() {
  if (!requireSession()) {
    return;
  }
  if (!scanNearbyNetworks()) {
    sendError(500, "Falló el escaneo pasivo de Wi-Fi");
    return;
  }
  sendJson(200, scanResultsJson());
}

void handleConnect() {
  if (!requireSession()) {
    return;
  }
  const String ssid = server.arg("ssid");
  const String password = server.arg("password");
  if (ssid.isEmpty() || ssid.length() > 32 || password.length() > 64) {
    sendError(400, "SSID o contraseña no válidos");
    return;
  }
  startStaConnection({ssid, password}, true);
  sendJson(202, "{\"ok\":true,\"message\":\"Intentando conectar\"}");
}

void handleSdFormat() {
  if (!requireSession()) {
    return;
  }
  if (server.arg("confirm") != "FORMATEAR") {
    sendError(400, "Confirma el formato desde la página Resumen");
    return;
  }
  if (sdFormatRunning) {
    sendError(409, "Ya hay un formateo en curso");
    return;
  }
  if (ouiUpdateRunning || ouiUploadRunning) {
    sendError(409, "Espera que termine la operación IEEE");
    return;
  }
  if (!startSdFormatTask()) {
    sendError(503, "No se pudo iniciar la tarea de formato");
    return;
  }
  sendJson(202, "{\"ok\":true,\"message\":\"Formato de microSD iniciado\"}");
}

void handleOuiUpdate() {
  if (!requireSession()) {
    return;
  }
  if (WiFi.status() != WL_CONNECTED) {
    sendError(503, "Conecta la STA a una red con Internet para actualizar IEEE");
    return;
  }
  if (!isOuiStorageReady()) {
    sendError(503, "El almacenamiento local no está disponible");
    return;
  }
  if (ouiUpdateRunning || ouiUploadRunning) {
    sendError(409, "Ya hay una operación IEEE en curso");
    return;
  }
  if (!scheduleOuiUpdate()) {
    sendError(503, "No se pudo iniciar la actualización IEEE");
    return;
  }
  sendJson(202, "{\"ok\":true,\"message\":\"Actualización IEEE iniciada\"}");
}

void handleOuiCsvDownload(const OuiDatabase &database) {
  if (!requireSession()) {
    return;
  }
  if (!isOuiStorageReady()) {
    sendError(503, "El almacenamiento local no está disponible");
    return;
  }
  fs::FS &filesystem = ouiStorage();
  if (!validateOuiFile(filesystem, database, database.filePath)) {
    const String error =
        String("La base IEEE ") + database.registry + " no existe o no es válida";
    sendError(404, error);
    return;
  }
  File file = filesystem.open(database.filePath, FILE_READ);
  if (!file) {
    const String error =
        String("No hay una base IEEE ") + database.registry + " descargada";
    sendError(404, error);
    return;
  }
  server.sendHeader("Content-Disposition",
                    String("attachment; filename=") + database.downloadFilename);
  server.streamFile(file, "text/csv; charset=utf-8");
  file.close();
}

void handleOuiCsvDownload() {
  handleOuiCsvDownload(OUI_DATABASES[0]);
}

void failOuiUpload(int statusCode, const String &message) {
  if (ouiUploadFile) {
    ouiUploadFile.close();
  }
  if (ouiUploadDatabase != nullptr && isOuiStorageReady()) {
    fs::FS &filesystem = ouiStorage();
    if (filesystem.exists(ouiUploadDatabase->temporaryPath)) {
      filesystem.remove(ouiUploadDatabase->temporaryPath);
    }
  }
  ouiUploadSucceeded = false;
  ouiUploadErrorStatus = statusCode;
  ouiUploadError = message;
}

void handleOuiUploadChunk(const OuiDatabase &database) {
  HTTPUpload &upload = server.upload();
  if (upload.status == UPLOAD_FILE_START) {
    ouiUploadDatabase = &database;
    ouiUploadBytes = 0;
    ouiUploadSucceeded = false;
    ouiUploadErrorStatus = 400;
    ouiUploadError = "";
    ouiUploadRunning = true;

    if (!requireSession()) {
      failOuiUpload(401, "Sesión no autorizada");
      return;
    }
    if (ouiUpdateRunning || sdFormatRunning) {
      failOuiUpload(409, "Espera que termine la operación en curso");
      return;
    }
    if (upload.name != "file") {
      failOuiUpload(400, "No se recibió el campo de archivo CSV");
      return;
    }
    if (!isOuiStorageReady()) {
      failOuiUpload(503, "El almacenamiento local no está disponible");
      return;
    }

    fs::FS &filesystem = ouiStorage();
    if (!filesystem.exists(OUI_DIRECTORY) &&
        !filesystem.mkdir(OUI_DIRECTORY)) {
      failOuiUpload(500, "No se pudo crear /ieee en el almacenamiento");
      return;
    }
    if (filesystem.exists(database.temporaryPath) &&
        !filesystem.remove(database.temporaryPath)) {
      failOuiUpload(500, "No se pudo limpiar el archivo temporal anterior");
      return;
    }
    ouiUploadFile = filesystem.open(database.temporaryPath, FILE_WRITE);
    if (!ouiUploadFile) {
      failOuiUpload(500, "No se pudo crear el archivo temporal");
    }
    return;
  }

  if (ouiUploadDatabase != &database || !ouiUploadError.isEmpty()) {
    return;
  }
  if (upload.status == UPLOAD_FILE_WRITE) {
    constexpr size_t MAX_OUI_BYTES = 8U * 1024U * 1024U;
    if (!ouiUploadFile ||
        upload.currentSize > MAX_OUI_BYTES - ouiUploadBytes) {
      failOuiUpload(413, "El CSV supera el límite de 8 MB");
      return;
    }
    const size_t written = ouiUploadFile.write(upload.buf, upload.currentSize);
    if (written != upload.currentSize) {
      failOuiUpload(507, "No hay espacio suficiente para guardar el CSV");
      return;
    }
    ouiUploadBytes += written;
    return;
  }
  if (upload.status == UPLOAD_FILE_ABORTED) {
    failOuiUpload(400, "La carga del CSV fue interrumpida");
    return;
  }
  if (upload.status != UPLOAD_FILE_END) {
    return;
  }

  ouiUploadFile.flush();
  const size_t storedBytes = ouiUploadFile.size();
  ouiUploadFile.close();
  fs::FS &filesystem = ouiStorage();
  if (storedBytes != ouiUploadBytes || storedBytes < 1000 ||
      !validateOuiFile(filesystem, database, database.temporaryPath)) {
    failOuiUpload(400, "El archivo no es un CSV IEEE válido para esta base");
    return;
  }
  if (!installOuiTempDatabase(filesystem, database)) {
    failOuiUpload(500, "No se pudo instalar el CSV; se conserva la base anterior");
    return;
  }

  Preferences cachePreferences;
  if (cachePreferences.begin("oui-cache", false)) {
    cachePreferences.remove(database.etagKey);
    cachePreferences.remove(database.modifiedKey);
    cachePreferences.end();
  } else {
    Serial.printf("IEEE %s: CSV cargado, pero no se limpiaron los validadores HTTP\n",
                  database.registry);
  }
  ouiUploadSucceeded = true;
}

void handleOuiUploadComplete(const OuiDatabase &database) {
  if (!requireSession()) {
    return;
  }
  if (ouiUploadDatabase != &database) {
    sendError(400, "No se recibió ningún archivo CSV");
  } else if (!ouiUploadError.isEmpty()) {
    sendError(ouiUploadErrorStatus, ouiUploadError);
  } else if (!ouiUploadSucceeded) {
    sendError(400, "La carga del CSV no se completó");
  } else {
    const String response =
        String("{\"ok\":true,\"registry\":\"") + database.registry + "\"}";
    sendJson(200, response);
  }
  ouiUploadFile = File();
  ouiUploadDatabase = nullptr;
  ouiUploadBytes = 0;
  ouiUploadError = "";
  ouiUploadSucceeded = false;
  ouiUploadRunning = false;
}

void handlePing() {
  if (!requireSession()) {
    return;
  }
  server.sendHeader("Cache-Control", "no-store");
  server.send(204, "text/plain", "");
}

void handleGatewayPing() {
  if (!requireSession()) {
    return;
  }
  if (WiFi.status() != WL_CONNECTED) {
    sendError(503, "Conecta la STA a una red para probar su puerta de enlace");
    return;
  }

  const uint32_t now = millis();
  if (gatewayPingAttempted && now - lastGatewayPingAt < 3000) {
    sendError(429, "Espera unos segundos antes de repetir la prueba");
    return;
  }

  const IPAddress gateway = WiFi.gatewayIP();
  if (gateway == IPAddress(0, 0, 0, 0)) {
    sendError(503, "La red conectada no informó una puerta de enlace");
    return;
  }

  gatewayPingAttempted = true;
  lastGatewayPingAt = now;
  const bool reachable = Ping.ping(gateway, 1);
  String body = F("{\"target\":\"");
  body += gateway.toString();
  body += F("\",\"reachable\":");
  body += reachable ? F("true") : F("false");
  body += F(",\"averageMs\":");
  if (reachable) {
    body += String(Ping.averageTime(), 1);
  } else {
    body += F("null");
  }
  body += '}';
  sendJson(200, body);
}

bool isStaSubnetUnicastTarget(const IPAddress &target) {
  const IPAddress local = WiFi.localIP();
  const IPAddress mask = WiFi.subnetMask();
  bool sameSubnet = true;
  bool networkAddress = true;
  bool broadcastAddress = true;
  for (size_t i = 0; i < 4; ++i) {
    const uint8_t networkOctet = local[i] & mask[i];
    sameSubnet &= (target[i] & mask[i]) == networkOctet;
    networkAddress &= target[i] == networkOctet;
    broadcastAddress &=
        target[i] == static_cast<uint8_t>(networkOctet | ~mask[i]);
  }
  return sameSubnet && !networkAddress && !broadcastAddress &&
         target[0] < 224 && target[0] != 127 && target != local;
}

void handleDevicePing() {
  if (!requireSession()) {
    return;
  }
  if (WiFi.status() != WL_CONNECTED) {
    sendError(503, "Conecta la STA a la LAN antes de hacer ping");
    return;
  }

  const String ipText = server.arg("ip");
  IPAddress target;
  if (!target.fromString(ipText) || target.toString() != ipText) {
    sendError(400, "La IP del dispositivo no es válida");
    return;
  }

  if (!isStaSubnetUnicastTarget(target)) {
    sendError(403, "El ping se limita a una IP unicast de la LAN conectada");
    return;
  }

  const uint32_t now = millis();
  if (!devicePingWindowStarted || now - devicePingWindowStartedAt >= 60000) {
    devicePingWindowStarted = true;
    devicePingWindowStartedAt = now;
    devicePingAttemptsInWindow = 0;
  }
  if (devicePingAttemptsInWindow >= 30) {
    sendError(429, "Se alcanzó el límite de 30 pings por minuto");
    return;
  }
  if (devicePingAttempted && now - lastDevicePingAt < 1000) {
    sendError(429, "Espera antes de enviar el siguiente ping");
    return;
  }
  devicePingAttempted = true;
  lastDevicePingAt = now;
  ++devicePingAttemptsInWindow;

  const bool reachable = Ping.ping(target, 1);
  String body = F("{\"target\":\"");
  body += target.toString();
  body += F("\",\"reachable\":");
  body += reachable ? F("true") : F("false");
  body += F(",\"averageMs\":");
  if (reachable) {
    body += String(Ping.averageTime(), 1);
  } else {
    body += F("null");
  }
  body += '}';
  sendJson(200, body);
}

bool readHttpHeaderLine(WiFiClient &client, String &line, uint32_t startedAt) {
  line = "";
  while (millis() - startedAt < 2500UL) {
    while (client.available() > 0) {
      const int value = client.read();
      if (value < 0) {
        break;
      }
      if (value == '\n') {
        return true;
      }
      if (value != '\r' && line.length() < 256) {
        line += static_cast<char>(value);
      }
    }
    if (!client.connected()) {
      return !line.isEmpty();
    }
    delay(1);
  }
  return false;
}

bool responseIsHtml(WiFiClient &client, int &statusCode) {
  const uint32_t startedAt = millis();
  String line;
  if (!readHttpHeaderLine(client, line, startedAt) || !line.startsWith("HTTP/")) {
    return false;
  }
  const int statusSeparator = line.indexOf(' ');
  if (statusSeparator < 0) {
    return false;
  }
  statusCode = line.substring(statusSeparator + 1,
                              statusSeparator + 4)
                   .toInt();
  if (statusCode < 100 || statusCode > 599) {
    return false;
  }

  String contentType;
  size_t headerBytes = line.length();
  while (headerBytes < 2048 && readHttpHeaderLine(client, line, startedAt)) {
    headerBytes += line.length() + 2;
    if (line.isEmpty()) {
      break;
    }
    const int separator = line.indexOf(':');
    if (separator > 0 &&
        line.substring(0, separator).equalsIgnoreCase("Content-Type")) {
      contentType = line.substring(separator + 1);
      contentType.trim();
      contentType.toLowerCase();
    }
  }
  return contentType.startsWith("text/html");
}

void handleHttpServerCheck() {
  if (!requireSession()) {
    return;
  }
  if (WiFi.status() != WL_CONNECTED) {
    sendError(503, "Conecta la STA a la LAN antes de comprobar HTTP");
    return;
  }

  const String ipText = server.arg("ip");
  IPAddress target;
  if (!target.fromString(ipText) || target.toString() != ipText) {
    sendError(400, "La IP del dispositivo no es válida");
    return;
  }
  if (!isStaSubnetUnicastTarget(target)) {
    sendError(403,
              "La comprobación HTTP se limita a una IP unicast de la LAN "
              "conectada");
    return;
  }

  const uint32_t now = millis();
  if (!httpProbeWindowStarted || now - httpProbeWindowStartedAt >= 60000UL) {
    httpProbeWindowStarted = true;
    httpProbeWindowStartedAt = now;
    httpProbeAttemptsInWindow = 0;
  }
  if (httpProbeAttemptsInWindow >= 64) {
    sendError(429, "Se alcanzó el límite de comprobaciones HTTP por minuto");
    return;
  }
  if (httpProbeAttempted && now - lastHttpProbeAt < 1000UL) {
    sendError(429, "Espera antes de comprobar otra IP");
    return;
  }
  httpProbeAttempted = true;
  lastHttpProbeAt = now;
  ++httpProbeAttemptsInWindow;

  WiFiClient client;
  client.setTimeout(1000);
  const uint32_t connectStartedAt = millis();
  const bool connected = client.connect(target, 80, 1200);
  const uint32_t latencyMs = millis() - connectStartedAt;
  int statusCode = 0;
  bool html = false;
  if (connected) {
    client.print(F("GET / HTTP/1.0\r\nHost: "));
    client.print(ipText);
    client.print(F("\r\nConnection: close\r\n\r\n"));
    html = responseIsHtml(client, statusCode);
  }
  client.stop();

  String body = F("{\"ip\":\"");
  body += target.toString();
  body += F("\",\"port\":80,\"connected\":");
  body += connected ? F("true") : F("false");
  body += F(",\"html\":");
  body += html ? F("true") : F("false");
  body += F(",\"status\":");
  body += String(statusCode);
  body += F(",\"latencyMs\":");
  body += String(latencyMs);
  body += '}';
  sendJson(200, body);
}

int32_t accessPointClientRssi() {
  wifi_sta_list_t stations{};
  if (esp_wifi_ap_get_sta_list(&stations) != ESP_OK || stations.num == 0) {
    return 0;
  }
  return stations.sta[0].rssi;
}

void handleTransferTest() {
  if (!requireSession()) {
    return;
  }
  size_t bytes = static_cast<size_t>(server.arg("bytes").toInt());
  bytes = std::max<size_t>(32 * 1024, std::min(bytes, MAX_TEST_BYTES));

  static uint8_t block[1024];
  static bool blockReady = false;
  if (!blockReady) {
    for (size_t i = 0; i < sizeof(block); ++i) {
      block[i] = static_cast<uint8_t>((i * 37U + 19U) & 0xFFU);
    }
    blockReady = true;
  }

  server.sendHeader("Cache-Control", "no-store");
  server.sendHeader("X-Transfer-Bytes", String(bytes));
  server.setContentLength(bytes);
  server.send(200, "application/octet-stream", "");

  size_t sent = 0;
  while (sent < bytes && server.client().connected()) {
    const size_t chunk = std::min<size_t>(sizeof(block), bytes - sent);
    server.sendContent(reinterpret_cast<const char *>(block), chunk);
    sent += chunk;
    delay(0);
  }
}

void handleRecordPoint() {
  if (!requireSession()) {
    return;
  }
  if (!filesystemReady) {
    sendError(503, "LittleFS no está disponible");
    return;
  }

  const String name = sanitizePointName(server.arg("name"));
  float mbps = 0;
  float latencyMs = 0;
  if (name.isEmpty() || !parseFloatArgument(server.arg("mbps"), mbps) ||
      !parseFloatArgument(server.arg("latencyMs"), latencyMs) || mbps < 0 ||
      mbps > 10000 || latencyMs < 0 || latencyMs > 120000) {
    sendError(400, "Nombre, velocidad o latencia no válidos");
    return;
  }

  SurveyPoint point{millis(), name, mbps, accessPointClientRssi(),
                    static_cast<uint8_t>(WiFi.channel()), latencyMs};
  SurveyPoint previous;
  const bool hasPrevious = findPreviousPoint(name, previous);
  const PointAnalysis analysis =
      analyzePoint(point, hasPrevious ? &previous : nullptr);
  if (!appendSurveyPoint(point)) {
    sendError(500, "No se pudo guardar el punto en LittleFS");
    return;
  }
  latestAnalysis = analysis;
  latestPointName = name;

  if (point.rssi < 0) {
    Serial.printf("Punto %s: %.3f Mbps, RSSI %ld dBm, canal %u\n",
                  point.name.c_str(), point.mbps,
                  static_cast<long>(point.rssi), point.channel);
  } else {
    Serial.printf("Punto %s: %.3f Mbps, RSSI no disponible, canal %u\n",
                  point.name.c_str(), point.mbps, point.channel);
  }
  sendJson(201, "{\"ok\":true}");
}

void handlePoints() {
  if (!requireSession()) {
    return;
  }
  if (!filesystemReady) {
    sendError(503, "LittleFS no está disponible");
    return;
  }
  String points;
  if (!pointsJson(points)) {
    sendError(500, "No se pudo leer la lista de puntos en LittleFS");
    return;
  }
  sendJson(200, points);
}

void handleClearPoints() {
  if (!requireSession()) {
    return;
  }
  if (!filesystemReady) {
    sendError(503, "LittleFS no está disponible");
    return;
  }
  if (LittleFS.exists(POINTS_FILE) && !LittleFS.remove(POINTS_FILE)) {
    Serial.println(F("ERROR: no se pudo borrar points.csv"));
    sendError(500, "No se pudieron borrar los puntos guardados");
    return;
  }

  latestPointName = "";
  latestAnalysis =
      {0, "Sin datos", "Ejecuta una medición para analizar el punto", ""};
  updateDisplay();
  Serial.println(F("[Portal] Se borraron los puntos guardados"));
  sendJson(200, "{\"ok\":true}");
}

void handleCctvAssets() {
  if (!requireSession()) {
    return;
  }
  if (!filesystemReady) {
    sendError(503, "LittleFS no está disponible");
    return;
  }
  sendJson(200, cctvAssetsJson());
}

void handleArpNeighbors() {
  if (!requireSession()) {
    return;
  }
  if (WiFi.status() != WL_CONNECTED) {
    sendError(503, "Conecta la STA a la red para observar vecinos ARP");
    return;
  }
  sendJson(200, arpNeighborsJson());
}

void handleScanCsvDownload() {
  if (!requireSession()) {
    return;
  }

  String body = F("ssid,bssid,channel,rssi_dbm,encryption,evaluation\r\n");
  body.reserve(body.length() + scanResults.size() * 128);
  for (const ScannedNetwork &network : scanResults) {
    body += csvEscape(network.ssid);
    body += ',';
    body += csvEscape(network.bssid);
    body += ',';
    body += String(network.channel);
    body += ',';
    body += String(network.rssi);
    body += ',';
    body += csvEscape(encryptionLabel(network.auth));
    body += ',';
    body += csvEscape(riskLabel(network.auth));
    body += F("\r\n");
  }

  server.sendHeader("Content-Disposition",
                    "attachment; filename=wifi_scan.csv");
  server.send(200, "text/csv; charset=utf-8", body);
}

void handleArpNeighborsCsvDownload() {
  if (!requireSession()) {
    return;
  }
  if (WiFi.status() != WL_CONNECTED) {
    sendError(503, "Conecta la STA a la red para exportar vecinos ARP");
    return;
  }

  String body = F("ip,mac,manufacturer,last_seen_seconds\r\n");
  body.reserve(body.length() + arpObservations.size() * 120);
  for (const ArpObservation &entry : arpObservations) {
    body += csvEscape(entry.ip);
    body += ',';
    body += csvEscape(entry.mac);
    body += ',';
    body += csvEscape(ouiManufacturerForMac(entry.mac));
    body += ',';
    body += String((millis() - entry.lastSeenAt) / 1000UL);
    body += F("\r\n");
  }

  server.sendHeader("Content-Disposition",
                    "attachment; filename=arp_observations.csv");
  server.send(200, "text/csv; charset=utf-8", body);
}

void handleAddCctvAsset() {
  if (!requireSession()) {
    return;
  }
  if (!filesystemReady) {
    sendError(503, "LittleFS no está disponible");
    return;
  }

  IPAddress ip;
  String mac;
  const String ipInput = server.arg("ip");
  const String name = sanitizeAssetValue(server.arg("name"), 32);
  const String type = server.arg("type");
  if (!ip.fromString(ipInput) || name.isEmpty() || !isCctvAssetType(type) ||
      !normalizeMacAddress(server.arg("mac"), mac)) {
    sendError(400, "IP, nombre, tipo o dirección MAC no válidos");
    return;
  }

  CctvAsset asset{ip.toString(),
                  name,
                  type,
                  mac,
                  sanitizeAssetValue(server.arg("manufacturer"), 32),
                  sanitizeAssetValue(server.arg("model"), 32),
                  sanitizeAssetValue(server.arg("firmware"), 24)};
  for (const CctvAsset &saved : cctvAssets) {
    if (saved.ip == asset.ip || saved.mac == asset.mac) {
      sendError(409, "La IP o la MAC ya están registradas");
      return;
    }
  }
  if (!appendCctvAsset(asset)) {
    sendError(500, "No se pudo guardar el equipo en LittleFS");
    return;
  }
  cctvAssets.push_back(asset);
  Serial.printf("[Inventario] Equipo agregado: %s (%s)\n", asset.name.c_str(),
                asset.ip.c_str());
  sendJson(201, "{\"ok\":true}");
}

void handleClearCctvAssets() {
  if (!requireSession()) {
    return;
  }
  if (!filesystemReady) {
    sendError(503, "LittleFS no está disponible");
    return;
  }
  if (LittleFS.exists(CCTV_ASSETS_FILE) &&
      !LittleFS.remove(CCTV_ASSETS_FILE)) {
    Serial.println(F("ERROR: no se pudo borrar el inventario CCTV"));
    sendError(500, "No se pudo borrar el inventario CCTV");
    return;
  }
  cctvAssets.clear();
  Serial.println(F("[Inventario] Se borró el inventario CCTV"));
  sendJson(200, "{\"ok\":true}");
}

void handleClientError() {
  if (!requireSession()) {
    return;
  }

  String message = server.arg("message");
  message.trim();
  if (message.isEmpty()) {
    sendError(400, "El mensaje de error está vacío");
    return;
  }
  if (message.length() > 240) {
    message.remove(240);
  }
  for (size_t i = 0; i < message.length(); ++i) {
    if (static_cast<uint8_t>(message[i]) < 0x20 ||
        static_cast<uint8_t>(message[i]) == 0x7f) {
      message[i] = ' ';
    }
  }
  Serial.printf("[Portal] Error del navegador: %s\n", message.c_str());
  server.send(204, "text/plain", "");
}

void handleCsvDownload() {
  if (!requireSession()) {
    return;
  }
  if (!filesystemReady) {
    sendError(503, "LittleFS no está disponible");
    return;
  }
  if (!LittleFS.exists(POINTS_FILE)) {
    File emptyFile = LittleFS.open(POINTS_FILE, FILE_WRITE);
    if (!emptyFile) {
      sendError(500, "No se pudo crear el archivo CSV");
      return;
    }
    emptyFile.println(F("uptime_ms,name,mbps,rssi_dbm,channel,latency_ms"));
    emptyFile.close();
  }
  File file = LittleFS.open(POINTS_FILE, FILE_READ);
  if (!file) {
    sendError(500, "No se pudo abrir el archivo CSV");
    return;
  }
  server.sendHeader("Content-Disposition",
                    "attachment; filename=site_survey_points.csv");
  server.streamFile(file, "text/csv; charset=utf-8");
  file.close();
}

void handleCctvAssetsCsvDownload() {
  if (!requireSession()) {
    return;
  }
  if (!filesystemReady) {
    sendError(503, "LittleFS no está disponible");
    return;
  }

  server.sendHeader("Content-Disposition",
                    "attachment; filename=cctv_inventory.csv");
  if (!LittleFS.exists(CCTV_ASSETS_FILE)) {
    server.send(200, "text/csv; charset=utf-8",
                "ip,name,type,mac,manufacturer,model,firmware\n");
    return;
  }

  File file = LittleFS.open(CCTV_ASSETS_FILE, FILE_READ);
  if (!file) {
    sendError(500, "No se pudo abrir el inventario CCTV");
    return;
  }
  server.streamFile(file, "text/csv; charset=utf-8");
  file.close();
}

void handleNotFound() {
  if (server.uri().startsWith("/api/")) {
    sendError(404, "Ruta API no encontrada");
    return;
  }
  server.sendHeader("Location", "http://192.168.4.1/");
  server.sendHeader("Cache-Control", "no-store");
  server.send(302, "text/plain", "");
}

void handleRoot();

void configureRoutes() {
  server.on("/", HTTP_GET, handleRoot);
  server.on("/api/status", HTTP_GET, []() {
    if (requireSession()) {
      sendJson(200, statusJson());
    }
  });
  server.on("/api/scan", HTTP_POST, handleScan);
  server.on("/api/connect", HTTP_POST, handleConnect);
  server.on("/api/sd/format", HTTP_POST, handleSdFormat);
  server.on("/api/oui/update", HTTP_POST, handleOuiUpdate);
  server.on("/api/oui.csv", HTTP_GET, []() {
    handleOuiCsvDownload();
  });
  server.on("/api/oui/upload/ma-l", HTTP_POST,
            []() { handleOuiUploadComplete(OUI_DATABASES[0]); },
            []() { handleOuiUploadChunk(OUI_DATABASES[0]); });
  server.on("/api/oui/upload/ma-m", HTTP_POST,
            []() { handleOuiUploadComplete(OUI_DATABASES[1]); },
            []() { handleOuiUploadChunk(OUI_DATABASES[1]); });
  server.on("/api/oui/upload/ma-s", HTTP_POST,
            []() { handleOuiUploadComplete(OUI_DATABASES[2]); },
            []() { handleOuiUploadChunk(OUI_DATABASES[2]); });
  server.on("/api/oui-mam.csv", HTTP_GET, []() {
    handleOuiCsvDownload(OUI_DATABASES[1]);
  });
  server.on("/api/oui36.csv", HTTP_GET, []() {
    handleOuiCsvDownload(OUI_DATABASES[2]);
  });
  server.on("/api/ping", HTTP_GET, handlePing);
  server.on("/api/gateway-ping", HTTP_GET, handleGatewayPing);
  server.on("/api/device-ping", HTTP_GET, handleDevicePing);
  server.on("/api/http-server-check", HTTP_GET, handleHttpServerCheck);
  server.on("/api/test", HTTP_GET, handleTransferTest);
  server.on("/api/record", HTTP_POST, handleRecordPoint);
  server.on("/api/points", HTTP_GET, handlePoints);
  server.on("/api/points", HTTP_DELETE, handleClearPoints);
  server.on("/api/cctv-assets", HTTP_GET, handleCctvAssets);
  server.on("/api/cctv-assets", HTTP_POST, handleAddCctvAsset);
  server.on("/api/cctv-assets", HTTP_DELETE, handleClearCctvAssets);
  server.on("/api/arp-neighbors", HTTP_GET, handleArpNeighbors);
  server.on("/api/scan.csv", HTTP_GET, handleScanCsvDownload);
  server.on("/api/arp-neighbors.csv", HTTP_GET,
            handleArpNeighborsCsvDownload);
  server.on("/api/client-error", HTTP_POST, handleClientError);
  server.on("/api/points.csv", HTTP_GET, handleCsvDownload);
  server.on("/api/cctv-assets.csv", HTTP_GET, handleCctvAssetsCsvDownload);
  server.onNotFound(handleNotFound);
  server.begin();
}

void startAccessPoint() {
  WiFi.mode(WIFI_AP_STA);
  WiFi.setSleep(false);
  if (!WiFi.softAPConfig(apAddress, apAddress, apMask)) {
    Serial.println(F("ERROR: no se pudo configurar la IP del punto de acceso"));
  }
  accessPointReady = WiFi.softAP(AP_SSID, AP_PASSWORD, 1, false, 4);
  if (accessPointReady) {
    Serial.printf("AP %s activo en %s\n", AP_SSID,
                  WiFi.softAPIP().toString().c_str());
    dnsServerReady = dnsServer.start(53, "*", apAddress);
    if (!dnsServerReady) {
      Serial.println(F("ERROR: no se pudo iniciar DNS para el portal cautivo"));
    }
  } else {
    connectionMessage = "Error al iniciar el punto de acceso";
    Serial.println(F("ERROR: no se pudo iniciar el AP"));
  }
}

void provisioningEventHandler(arduino_event_t *event) {
  portENTER_CRITICAL(&bleEventMux);
  switch (event->event_id) {
  case ARDUINO_EVENT_PROV_START:
    bleStartPending = true;
    break;
  case ARDUINO_EVENT_PROV_CRED_RECV:
    memcpy(bleReceivedSsid, event->event_info.prov_cred_recv.ssid, 32);
    bleReceivedSsid[32] = '\0';
    memcpy(bleReceivedPassword, event->event_info.prov_cred_recv.password, 64);
    bleReceivedPassword[64] = '\0';
    bleCredentialsPending = true;
    break;
  case ARDUINO_EVENT_PROV_CRED_SUCCESS:
    bleSuccessPending = true;
    break;
  case ARDUINO_EVENT_PROV_CRED_FAIL:
    bleFailurePending = true;
    bleAuthFailurePending =
        event->event_info.prov_fail_reason == NETWORK_PROV_WIFI_STA_AUTH_ERROR;
    break;
  default:
    break;
  }
  portEXIT_CRITICAL(&bleEventMux);
}

void restoreAccessPoint() {
  if ((WiFi.getMode() & WIFI_AP) != 0) {
    return;
  }

  WiFi.mode(WIFI_AP_STA);
  if (!WiFi.softAPConfig(apAddress, apAddress, apMask)) {
    Serial.println(F("ERROR: no se pudo restaurar la IP del punto de acceso"));
  }
  accessPointReady = WiFi.softAP(AP_SSID, AP_PASSWORD, 1, false, 4);
  if (!accessPointReady) {
    Serial.println(F("ERROR: no se pudo restaurar el punto de acceso"));
    return;
  }
  dnsServer.stop();
  dnsServerReady = dnsServer.start(53, "*", apAddress);
  if (!dnsServerReady) {
    Serial.println(F("ERROR: no se pudo restaurar DNS del portal cautivo"));
  }
}

void startBleProvisioning(bool force) {
  if (bleProvisioningRequested || (!force && !savedNetworks.empty())) {
    return;
  }

  uint8_t mac[6];
  if (esp_read_mac(mac, ESP_MAC_WIFI_STA) != ESP_OK) {
    lastNetworkError = "No se pudo leer la MAC para iniciar BLE";
    Serial.println(F("ERROR: no se pudo leer la MAC para iniciar BLE"));
    return;
  }
  snprintf(bleServiceName, sizeof(bleServiceName), "Prov_%02X%02X%02X",
           mac[3], mac[4], mac[5]);
  snprintf(bleProofOfPossession, sizeof(bleProofOfPossession), "%02X%02X%02X%02X",
           mac[2], mac[3], mac[4], mac[5]);

  WiFi.onEvent(provisioningEventHandler);
  bleProvisioningRequested = true;
  WiFiProv.beginProvision(
      NETWORK_PROV_SCHEME_BLE, NETWORK_PROV_SCHEME_HANDLER_FREE_BLE,
      NETWORK_PROV_SECURITY_1, bleProofOfPossession, bleServiceName, nullptr,
      nullptr, force || savedNetworks.empty());
  bleProvisioningActive = true;
  restoreAccessPoint();
  Serial.printf("Aprovisionamiento BLE iniciado: %s\n", bleServiceName);
}

void processBleProvisioningEvents() {
  bool started;
  bool succeeded;
  bool failed;
  bool authFailed;
  bool credentialsReceived;
  char ssid[sizeof(bleReceivedSsid)];
  char password[sizeof(bleReceivedPassword)];
  portENTER_CRITICAL(&bleEventMux);
  started = bleStartPending;
  succeeded = bleSuccessPending;
  failed = bleFailurePending;
  authFailed = bleAuthFailurePending;
  credentialsReceived = bleCredentialsPending;
  memcpy(ssid, bleReceivedSsid, sizeof(ssid));
  memcpy(password, bleReceivedPassword, sizeof(password));
  bleStartPending = false;
  bleSuccessPending = false;
  bleFailurePending = false;
  bleAuthFailurePending = false;
  bleCredentialsPending = false;
  portEXIT_CRITICAL(&bleEventMux);

  if (started) {
    bleProvisioningActive = true;
    connectionMessage = "Bluetooth listo para configurar Wi-Fi";
  }
  if (credentialsReceived && !succeeded) {
    lastNetworkError = "";
    connectionMessage = "Credenciales recibidas; probando Wi-Fi";
  }
  if (failed) {
    if (authFailed) {
      lastNetworkError = "BLE: clave Wi-Fi incorrecta (autenticación fallida)";
      connectionMessage = "Clave Wi-Fi incorrecta";
    } else {
      lastNetworkError =
          "BLE: no se encontró el AP; usa una red 2.4 GHz visible";
      connectionMessage = "Red Wi-Fi no encontrada";
    }
    bleProvisioningActive = true;
  }
  if (!succeeded) {
    return;
  }

  WiFiProv.endProvision();
  bleProvisioningActive = false;
  bleProvisioningRequested = false;
  restoreAccessPoint();
  if (!credentialsReceived || ssid[0] == '\0') {
    lastNetworkError = "BLE conectó, pero no se recibieron credenciales";
    return;
  }

  const SavedNetwork network{String(ssid), String(password)};
  if (!rememberNetwork(network)) {
    lastNetworkError = "Wi-Fi conectado, pero no se pudo guardar en NVS";
  } else {
    lastNetworkError = "";
  }
  connectionMessage = "Wi-Fi configurado por Bluetooth";
  if (WiFi.status() != WL_CONNECTED || WiFi.SSID() != network.ssid) {
    startStaConnection(network, false);
  }
}

void startFilesystem() {
  filesystemReady = LittleFS.begin(false);
  if (!filesystemReady) {
    Serial.println(F("ERROR: no se pudo montar LittleFS; no se formateó"));
    return;
  }
  Serial.printf("LittleFS listo: %u bytes usados de %u\n",
                static_cast<unsigned>(LittleFS.usedBytes()),
                static_cast<unsigned>(LittleFS.totalBytes()));
}

bool copyOuiDatabaseToSd(const OuiDatabase &database) {
  if (!LittleFS.exists(database.filePath)) {
    return true;
  }
  if (!validateOuiFile(LittleFS, database, database.filePath)) {
    if (validateOuiFile(SD_MMC, database, database.filePath)) {
      Serial.printf("IEEE %s: copia interna inválida; se usará la microSD\n",
                    database.registry);
      return true;
    }
    Serial.printf("IEEE %s: copia interna inválida; se conserva para diagnóstico\n",
                  database.registry);
    return false;
  }
  if (!SD_MMC.exists(OUI_DIRECTORY) && !SD_MMC.mkdir(OUI_DIRECTORY)) {
    Serial.printf("IEEE %s: no se pudo crear /ieee en la microSD\n",
                  database.registry);
    return false;
  }

  if (SD_MMC.exists(database.temporaryPath) &&
      !SD_MMC.remove(database.temporaryPath)) {
    Serial.printf("IEEE %s: no se pudo limpiar el temporal de la microSD\n",
                  database.registry);
    return false;
  }
  File source = LittleFS.open(database.filePath, FILE_READ);
  File destination = SD_MMC.open(database.temporaryPath, FILE_WRITE);
  if (!source || !destination) {
    if (source) {
      source.close();
    }
    if (destination) {
      destination.close();
    }
    SD_MMC.remove(database.temporaryPath);
    Serial.printf("IEEE %s: no se pudo abrir la migración a microSD\n",
                  database.registry);
    return false;
  }

  uint8_t buffer[4096];
  size_t copiedBytes = 0;
  bool copySucceeded = true;
  while (source.available()) {
    const size_t bytesRead = source.read(buffer, sizeof(buffer));
    if (bytesRead == 0 || destination.write(buffer, bytesRead) != bytesRead) {
      copySucceeded = false;
      break;
    }
    copiedBytes += bytesRead;
  }
  destination.flush();
  const size_t storedBytes = destination.size();
  source.close();
  destination.close();
  if (!copySucceeded || storedBytes != copiedBytes ||
      !validateOuiFile(SD_MMC, database, database.temporaryPath)) {
    SD_MMC.remove(database.temporaryPath);
    Serial.printf("IEEE %s: migración incompleta; se conserva la copia interna\n",
                  database.registry);
    return false;
  }

  if (SD_MMC.exists(database.backupPath) &&
      !SD_MMC.remove(database.backupPath)) {
    SD_MMC.remove(database.temporaryPath);
    Serial.printf("IEEE %s: no se pudo limpiar el respaldo anterior de la SD\n",
                  database.registry);
    return false;
  }
  const bool hadSdDatabase = SD_MMC.exists(database.filePath);
  if (hadSdDatabase &&
      !SD_MMC.rename(database.filePath, database.backupPath)) {
    SD_MMC.remove(database.temporaryPath);
    Serial.printf("IEEE %s: no se pudo respaldar la base anterior de la SD\n",
                  database.registry);
    return false;
  }
  if (!SD_MMC.rename(database.temporaryPath, database.filePath)) {
    if (hadSdDatabase) {
      SD_MMC.rename(database.backupPath, database.filePath);
    }
    SD_MMC.remove(database.temporaryPath);
    Serial.printf("IEEE %s: no se pudo instalar la copia en SD\n",
                  database.registry);
    return false;
  }
  if (hadSdDatabase && !SD_MMC.remove(database.backupPath)) {
    Serial.printf("IEEE %s: aviso: quedó un respaldo anterior en la SD\n",
                  database.registry);
  }
  Serial.printf("IEEE %s: copiada a microSD (%u bytes)\n", database.registry,
                static_cast<unsigned>(copiedBytes));
  return true;
}

bool migrateOuiDatabaseToSd() {
  if (!filesystemReady || !sdCardReady) {
    return true;
  }

  bool allCopied = true;
  for (const OuiDatabase &database : OUI_DATABASES) {
    if (!copyOuiDatabaseToSd(database)) {
      allCopied = false;
    }
  }
  if (!allCopied) {
    return false;
  }

  for (const OuiDatabase &database : OUI_DATABASES) {
    if (LittleFS.exists(database.filePath) &&
        !LittleFS.remove(database.filePath)) {
      Serial.printf("IEEE %s: base copiada a SD, pero no se liberó la copia interna\n",
                    database.registry);
    }
    if (LittleFS.exists(database.temporaryPath) &&
        !LittleFS.remove(database.temporaryPath)) {
      Serial.printf("IEEE %s: no se pudo eliminar un temporal interno antiguo\n",
                    database.registry);
    }
    if (LittleFS.exists(database.backupPath) &&
        !LittleFS.remove(database.backupPath)) {
      Serial.printf("IEEE %s: no se pudo eliminar un respaldo interno antiguo\n",
                    database.registry);
    }
  }
  ouiLookupCache.clear();
  return true;
}

void startSdCard() {
  if (!SD_MMC.setPins(PIN_SD_CLK, PIN_SD_CMD, PIN_SD_D0)) {
    Serial.println(F("ERROR: no se pudieron configurar los pines SDMMC; OUI usará LittleFS"));
    sdLastMessage = "No se pudieron configurar pines SDMMC";
    return;
  }
  sdCardReady =
      SD_MMC.begin("/sdcard", true, false, SDMMC_FREQ_PROBING);
  if (!sdCardReady || SD_MMC.cardType() == CARD_NONE) {
    sdCardReady = false;
    sdLastMessage = "No responde; revisa inserción y lector";
    Serial.println(F("ERROR: no se montó la microSD; OUI usará LittleFS"));
    return;
  }
  sdLastMessage = "MicroSD montada";
  Serial.printf("microSD lista: %llu MB totales, %llu MB usados\n",
                static_cast<unsigned long long>(SD_MMC.totalBytes() / 1048576ULL),
                static_cast<unsigned long long>(SD_MMC.usedBytes() / 1048576ULL));
  ouiStorageOnSd = migrateOuiDatabaseToSd();
  if (!ouiStorageOnSd) {
    Serial.println(F("IEEE OUI: no se completó la migración; se mantiene la copia disponible"));
  }
}

void startPreferences() {
  preferencesReady = preferences.begin("sitewifi", false);
  if (!preferencesReady) {
    Serial.println(F("ERROR: no se pudo abrir NVS; lista blanca no persistirá"));
    return;
  }
  loadSavedNetworks();
  gatewayMac = preferences.getString("gwmac", "");
  gatewayMacIp = preferences.getString("gwip", "");
  gatewayMacNetwork = preferences.getString("gwnet", "");
  Serial.printf("Redes guardadas en lista blanca: %u\n",
                static_cast<unsigned>(savedNetworks.size()));
}

void initializeDisplay() {
  pinMode(PIN_LCD_BL, OUTPUT);
  digitalWrite(PIN_LCD_BL, HIGH);
  if (!display->begin()) {
    Serial.println(F("ERROR: Arduino_GFX no pudo inicializar la pantalla"));
    return;
  }
  displayReady = true;
  display->fillScreen(RGB565_BLACK);
  updateDisplay();
}

void initializeStaReconnect() {
  if (savedNetworks.empty()) {
    return;
  }
  nextReconnectAt = millis();
  reconnectIndex = 0;
  maintainStaConnection();
}

static const char INDEX_HTML[] PROGMEM = R"HTML(
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#101827">
<title>ESP32 Site Survey</title>
<style>
:root{color-scheme:dark;--bg:#0b1220;--panel:#131e30;--line:#263650;--text:#e9f0fb;--muted:#9aabc2;--cyan:#5de1e6;--green:#73e0ad;--amber:#ffc66d;--red:#ff7d8a}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 20% 0,#172d44 0,transparent 42%),var(--bg);color:var(--text);font:15px/1.5 system-ui,-apple-system,Segoe UI,sans-serif}
.wrap{width:min(1120px,100%);margin:auto;padding:20px}.top{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:18px}.brand{display:flex;align-items:center;gap:12px}.logo{width:42px;height:42px;border-radius:13px;background:linear-gradient(135deg,#62e8dd,#5e8cff);display:grid;place-items:center;color:#071321;font-weight:900}.brand h1{font-size:19px;margin:0}.brand p{margin:2px 0 0;color:var(--muted);font-size:12px}.pill{border:1px solid var(--line);border-radius:999px;padding:6px 11px;color:var(--muted);font-size:12px}.pill.ok{color:var(--green);border-color:#34775d}.pill.warn{color:var(--amber);border-color:#765b31}
.nav{display:flex;gap:8px;overflow:auto;border-bottom:1px solid var(--line);margin-bottom:18px}.nav button{white-space:nowrap;background:transparent;color:var(--muted);border:0;border-bottom:2px solid transparent;padding:12px 14px;cursor:pointer;font:inherit}.nav button.active{color:var(--cyan);border-color:var(--cyan)}
.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:14px}.card{background:linear-gradient(160deg,rgba(24,38,59,.96),rgba(17,27,43,.96));border:1px solid var(--line);border-radius:16px;padding:17px;box-shadow:0 12px 34px rgba(0,0,0,.12)}.card h2,.card h3{margin:0 0 12px}.card h2{font-size:17px}.card h3{font-size:14px;color:var(--muted)}.span12{grid-column:span 12}.span8{grid-column:span 8}.span6{grid-column:span 6}.span4{grid-column:span 4}
.metric{font-size:24px;font-weight:750;letter-spacing:-.4px}.muted{color:var(--muted)}.small{font-size:12px}.row{display:flex;align-items:center;gap:9px;flex-wrap:wrap}.spread{justify-content:space-between}.stack{display:grid;gap:10px}.statgrid{display:grid;grid-template-columns:repeat(5,1fr);gap:10px}.stat{background:rgba(7,14,25,.35);border:1px solid var(--line);border-radius:12px;padding:12px}.stat label{display:block;color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.08em}.stat strong{display:block;margin-top:3px;font-size:16px;overflow-wrap:anywhere}
button,.button{background:linear-gradient(135deg,#5de1e6,#74a7ff);border:0;border-radius:10px;color:#071321;padding:10px 14px;cursor:pointer;font:inherit;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;gap:7px}button.secondary,.button.secondary{background:#22334b;color:var(--text);border:1px solid #344862}button.danger{background:#462832;color:#ffb6bf;border:1px solid #70424b}button:disabled{opacity:.5;cursor:wait}
input,select{width:100%;background:#0d1727;color:var(--text);border:1px solid #344762;border-radius:9px;padding:11px 12px;font:inherit;outline:none}input:focus,select:focus{border-color:var(--cyan)}label{display:grid;gap:5px;color:var(--muted);font-size:12px}
.formgrid{display:grid;grid-template-columns:1.5fr 1.5fr auto;align-items:end;gap:10px}.asset-formgrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));align-items:end;gap:10px}textarea{width:100%;min-height:110px;resize:vertical;background:#0d1727;color:var(--text);border:1px solid #344762;border-radius:9px;padding:11px 12px;font:inherit}.notice{border-left:3px solid var(--amber);padding:9px 12px;background:#30291d;color:#efd7a7;border-radius:0 9px 9px 0;font-size:12px}
.tablewrap{overflow:auto;border:1px solid var(--line);border-radius:10px}table{width:100%;border-collapse:collapse;min-width:650px;font-size:13px}th,td{text-align:left;padding:10px 11px;border-bottom:1px solid var(--line);vertical-align:top}th{color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.06em;background:#101a29}tr:last-child td{border-bottom:0}.risk-high{color:var(--red)}.risk-protected{color:var(--green)}.risk-standard{color:var(--amber)}
.storage-stack{display:grid;gap:14px}.storage-item{display:grid;gap:6px}.storage-summary{color:var(--muted);font-size:12px}.storage-bar{height:18px;display:flex;overflow:hidden;border:1px solid var(--line);border-radius:999px;background:#0d1727}.storage-used{height:100%;background:#ffd43b}.storage-free{height:100%;background:#e347dd}.storage-legend{display:flex;gap:14px;flex-wrap:wrap;color:var(--muted);font-size:11px}.storage-legend span{display:inline-flex;align-items:center;gap:6px}.storage-swatch{width:10px;height:10px;border-radius:3px;display:inline-block}.storage-swatch.used{background:#ffd43b}.storage-swatch.free{background:#e347dd}
.sd-format-progress{height:8px;overflow:hidden;border:1px solid var(--line);border-radius:999px;background:#0d1727}.sd-format-progress span{display:block;width:35%;height:100%;background:var(--cyan);animation:sd-format-slide 1.2s ease-in-out infinite alternate}@keyframes sd-format-slide{from{transform:translateX(0)}to{transform:translateX(185%)}}
.tabs{display:none}.tabs.active{display:block}.canvasbox{width:100%;overflow:hidden}canvas{width:100%;height:280px;display:block;background:#0d1727;border:1px solid var(--line);border-radius:10px}.spectrum-legend{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:7px;margin-top:10px}.legend-item{display:flex;align-items:center;gap:8px;min-width:0;padding:7px 9px;background:#101a29;border:1px solid var(--line);border-radius:8px}.legend-swatch{flex:0 0 11px;width:11px;height:11px;border-radius:50%}.legend-text{overflow-wrap:anywhere}
.error{color:var(--red);min-height:20px;font-size:13px}.toast{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);background:#263b52;border:1px solid #41627f;border-radius:10px;padding:10px 15px;z-index:10;display:none;max-width:90vw;align-items:center;justify-content:center;flex-wrap:wrap;gap:10px}.toast.show{display:flex}.toast span{flex:1 1 180px;user-select:text;overflow-wrap:anywhere}.hidden{display:none!important}.foot{color:var(--muted);font-size:11px;text-align:center;padding:20px 0}
@media(max-width:760px){.wrap{padding:14px}.span8,.span6,.span4{grid-column:span 12}.statgrid{grid-template-columns:repeat(2,1fr)}.formgrid,.asset-formgrid{grid-template-columns:1fr}.formgrid button,.asset-formgrid button{width:100%}.top{align-items:flex-start}.pill{font-size:11px}.card{padding:14px}canvas{height:240px}}
</style>
</head>
<body>
<div class="wrap">
  <header class="top">
    <div class="brand"><div class="logo">S</div><div><h1>ESP32 Site Survey</h1><p>Waveshare ESP32-S3-LCD-1.47B · auditoría pasiva</p></div></div>
    <div class="row"><span id="connectionPill" class="pill warn">Sin STA</span></div>
  </header>
  <nav class="nav">
    <button class="active" data-tab="overview">Resumen</button>
    <button data-tab="wifi">Wi-Fi y espectro</button>
    <button data-tab="test">Prueba de enlace</button>
    <button data-tab="devices">Dispositivos LAN</button>
    <button data-tab="cctv">Inventario CCTV</button>
    <button data-tab="points">Puntos guardados</button>
  </nav>
  <section class="tabs active" id="tab-overview">
    <div class="grid">
      <article class="card span12"><h2>Estado del sistema</h2><div class="statgrid">
        <div class="stat"><label>Punto de acceso</label><strong id="apName">--</strong></div>
        <div class="stat"><label>Portal</label><strong id="apIp">--</strong></div>
        <div class="stat"><label>Red STA</label><strong id="staName">--</strong></div>
        <div class="stat"><label>Señal STA</label><strong id="staRssi">--</strong></div>
        <div class="stat"><label>IP del ESP32 en el router</label><strong id="staIp">--</strong></div>
      </div><p id="statusMessage" class="muted small">Cargando estado…</p><p id="networkError" class="error"></p></article>
      <article class="card span12"><h2>Almacenamiento</h2><p class="muted small">Espacio para archivos en LittleFS y en la microSD. No representa la RAM ni todo el espacio de firmware del chip.</p><div class="storage-stack"><div class="storage-item"><strong>ESP32 · LittleFS</strong><div id="espStorageSummary" class="storage-summary">Consultando…</div><div id="espStorageBar" class="storage-bar" role="progressbar" aria-label="Almacenamiento LittleFS usado y libre" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"></div></div><div class="storage-item"><strong>microSD</strong><div id="sdStorageSummary" class="storage-summary">Consultando…</div><div id="sdStorageBar" class="storage-bar" role="progressbar" aria-label="Almacenamiento microSD usado y libre" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"></div><button id="formatSdBtn" class="danger" type="button" disabled>Formatear microSD</button><p id="sdFormatFeedback" class="muted small" aria-live="polite">El formato borra todos los archivos de la microSD.</p><div id="sdFormatProgress" class="sd-format-progress hidden" role="progressbar" aria-label="Formato de microSD en curso"><span></span></div></div></div><div class="storage-legend"><span><i class="storage-swatch used"></i>Usado</span><span><i class="storage-swatch free"></i>Libre</span></div><p id="storageStatus" class="muted small">Comprobando almacenamiento…</p></article>
      <article class="card span12"><h2>Configuración Bluetooth BLE</h2><p id="bleStatus" class="muted small">Consultando estado de BLE…</p></article>
      <article class="card span6"><div class="row spread"><h2>Conectar una red autorizada</h2><button class="secondary" id="scanBtnOverview">Escanear redes</button></div><p class="muted small">Escanea, selecciona tu red e introduce su clave. Se guardará en la lista blanca únicamente tras conectar correctamente.</p><p id="scanFeedback" class="muted small">Todavía no se ha realizado un escaneo.</p><div class="stack">
        <label>Redes encontradas<select id="networkSelect"><option value="">Escanea para ver redes</option></select></label>
        <label>Contraseña Wi-Fi<input id="wifiPassword" type="password" autocomplete="off" maxlength="64" placeholder="Vacía si la red es abierta"></label>
        <button id="connectBtn">Conectar y guardar</button>
      </div></article>
      <article class="card span6"><h2>Lista blanca</h2><p class="muted small">Redes guardadas en Preferences/NVS para reconexión automática. Las claves no se muestran en el portal.</p><div id="whitelist" class="stack muted small">Sin redes guardadas.</div></article>
      <article class="card span12"><div class="notice">El escaneo escucha anuncios Wi-Fi de forma pasiva; no intenta entrar, interrumpir ni probar redes. Úsalo solo en redes propias o con autorización.</div></article>
    </div>
  </section>
  <section class="tabs" id="tab-wifi">
    <div class="grid">
      <article class="card span12"><div class="row spread"><div><h2>Redes cercanas y canales</h2><p class="muted small">Escaneo pasivo en 2.4 GHz · canales 1–13 · la evaluación se basa solo en el cifrado anunciado.</p></div><div class="row"><button id="scanBtn">Escanear redes</button><a href="/api/scan.csv">Descargar CSV</a></div></div><div class="canvasbox"><canvas id="spectrum" width="1000" height="320"></canvas></div><div id="spectrumLegend" class="spectrum-legend muted small">Los SSID aparecerán aquí después del escaneo.</div><div class="notice" id="channelAdvice">Escanea redes para comparar los canales 1, 6 y 11.</div><div class="muted small">La recomendación estima solapamiento de señales anunciadas; no mide tráfico real ni cambia la configuración del router.</div></article>
      <article class="card span12"><h2>Auditoría pasiva</h2><div class="tablewrap"><table><thead><tr><th>SSID</th><th>BSSID</th><th>Canal</th><th>RSSI</th><th>Cifrado</th><th>Evaluación</th></tr></thead><tbody id="scanTable"><tr><td colspan="6" class="muted">Pulsa “Escanear redes”.</td></tr></tbody></table></div></article>
    </div>
  </section>
  <section class="tabs" id="tab-test">
    <div class="grid">
      <article class="card span8"><h2>Test de transmisión ESP32 → navegador</h2><p class="muted small">Mide el enlace AP del ESP32 al navegador; registra el RSSI del cliente conectado y el canal del AP. No requiere conectar una red STA.</p><div class="formgrid">
        <label>Tamaño de prueba<select id="testSize"><option value="262144">256 KB</option><option value="524288" selected>512 KB</option><option value="1048576">1 MB</option></select></label>
        <label>Nombre del punto<input id="pointName" maxlength="32" value="Camara_Entrada" placeholder="Ej. Camara_Entrada"></label>
        <button id="runTestBtn">Medir y registrar</button>
      </div><p id="testMessage" class="muted small">Listo para medir y guardar el punto.</p><div class="notice" id="analysisResult">Análisis local: combinación orientativa de señal, velocidad y latencia; la referencia de velocidad es 5 Mbps.</div></article>
      <article class="card span4"><h3>Último resultado</h3><div class="stack"><div><div class="metric" id="speedResult">-- Mbps</div><div class="muted small">Velocidad de descarga</div></div><div><strong id="latencyResult">-- ms</strong><div class="muted small">Latencia HTTP al dispositivo</div></div></div></article>
    </div>
  </section>
  <section class="tabs" id="tab-devices">
    <div class="grid">
      <article class="card span12"><h2>Ping de la puerta de enlace</h2><p class="muted small">Envía un único ping ICMP a la puerta de enlace de la red STA conectada.</p><div class="row"><button type="button" class="secondary" id="gatewayPingBtn">Probar gateway</button><span id="gatewayPingResult" class="muted small">Conecta la STA para realizar la prueba.</span></div></article>
      <article class="card span12"><div class="row spread"><div><h2>Bases IEEE MA-L, MA-M y MA-S</h2><p id="ouiStatus" class="muted small">Consultando estado de las bases locales…</p></div><div class="row"><button id="updateOuiBtn">Actualizar las tres bases</button><a class="button secondary" href="/api/oui.csv">Descargar MA-L</a><a class="button secondary" href="/api/oui-mam.csv">Descargar MA-M</a><a class="button secondary" href="/api/oui36.csv">Descargar MA-S</a></div></div><p class="muted small">La ESP32 necesita STA con Internet. Se guardan tres CSV separados en la microSD cuando está disponible (si no, LittleFS) y se cotejan prefijos IEEE de 24, 28 y 36 bits; si una descarga falla, se conserva la copia local válida de esa base.</p></article>
      <article class="card span12"><h3>Cargar CSV descargados en este equipo</h3><div class="asset-formgrid">
        <div><label>CSV MA-L<input id="ouiFileL" type="file" accept=".csv,text/csv"></label><button type="button" id="ouiUploadLBtn">Instalar MA-L</button></div>
        <div><label>CSV MA-M<input id="ouiFileM" type="file" accept=".csv,text/csv"></label><button type="button" id="ouiUploadMBtn">Instalar MA-M</button></div>
        <div><label>CSV MA-S<input id="ouiFileS" type="file" accept=".csv,text/csv"></label><button type="button" id="ouiUploadSBtn">Instalar MA-S</button></div>
      </div><p id="ouiUploadFeedback" class="muted small">Si la descarga directa desde la ESP32 falla, selecciona aquí cada CSV IEEE. El archivo se valida antes de reemplazar su base local.</p></article>
      <article class="card span12"><div class="row spread"><div><h2>Dispositivos de la LAN</h2><p class="muted small">Combina vecinos observados por ARP y equipos importados al inventario. No barre la red. Para revisar clientes DHCP, impórtalos en “Inventario CCTV” con IP y MAC; luego podrán probarse individualmente.</p></div><div class="row"><button id="refreshDevicesBtn">Actualizar dispositivos</button><button type="button" id="checkHttpServersBtn" class="secondary">Corroborar HTML</button><a class="button secondary" href="/api/arp-neighbors.csv">Descargar CSV ARP</a></div></div><p id="lanDevicesFeedback" class="muted small">Pulsa “Actualizar dispositivos” para cargar las observaciones e IP importadas.</p><p id="httpCheckFeedback" class="muted small">Al pulsar, se actualizan ARP e inventario y se comprueba HTTP/80 solo en las IP unicast de la subred STA.</p><div class="row"><button type="button" id="stopDevicePingBtn" class="danger" disabled>Finalizar ping</button><span id="devicePingFeedback" class="muted small">Selecciona un dispositivo para iniciar un ping acotado.</span></div><div class="tablewrap"><table><thead><tr><th>IP</th><th>Red</th><th>MAC</th><th>Titular IEEE</th><th>Nombre</th><th>Estado</th><th>Servidor HTTP/80</th><th>Ping</th></tr></thead><tbody id="lanDevicesTable"><tr><td colspan="8" class="muted">Todavía no hay datos cargados.</td></tr></table></div><p class="muted small">“Abrir HTTP” solo aparece cuando una IP ARP o importada responde en puerto 80 con Content-Type HTML. No se buscan otros puertos ni se enlazan servicios no confirmados. El ping sigue limitado a una IP unicast de la subred STA; una falta de respuesta ICMP no confirma que el equipo esté apagado.</p></article>
      <article class="card span12"><h2>Revisión defensiva manual</h2><p id="assetGuidance" class="muted small">Selecciona “Guía” en un equipo para ver recomendaciones generales. No se realizan pruebas de acceso, vulnerabilidad ni firmware.</p><div class="notice">En el router o en la interfaz oficial del equipo, revisa si UPnP está desactivado cuando no sea necesario, cambia las claves predeterminadas por claves únicas, limita el acceso remoto y comprueba la versión de firmware con el soporte oficial del fabricante. No descargues ni instales firmware de fuentes no oficiales.</div><p class="small"><a href="https://standards.ieee.org/products-programs/regauth/" target="_blank" rel="noopener">Consultar manualmente las asignaciones IEEE</a>. Desde esa página se accede a las listas oficiales. La coincidencia usa el prefijo asignado más específico; el resultado identifica al titular, no valida el equipo.</p></article>
      <article class="card span12"><h3>Resultados de comprobación web</h3><p class="muted small">Resultados de IP observadas por ARP o importadas. Se comprueba solo HTTP/80; no se exploran rangos ni otros puertos. La latencia es la conexión TCP medida por la ESP32.</p><div class="tablewrap"><table><thead><tr><th>IP</th><th>Puerto</th><th>Conexión</th><th>Latencia TCP</th><th>Respuesta</th><th>Enlace</th></tr></thead><tbody id="httpCheckResultsTable"><tr data-empty="true"><td colspan="6" class="muted">Todavía no hay comprobaciones.</td></tr></tbody></table></div></article>
    </div>
  </section>
  <section class="tabs" id="tab-cctv">
    <div class="grid">
      <article class="card span12"><h2>Inventario de equipos CCTV</h2><p class="muted small">Carga los datos desde la lista de clientes del router o desde la etiqueta del equipo. Al conectar la STA se consulta el ARP local para obtener la MAC de la puerta de enlace, se guarda en NVS y se coteja con la base IEEE local. Si el gateway no responde al ARP, importa su fila desde la tabla de clientes del router. No se escanean IP, puertos ni contraseñas.</p><div class="statgrid"><div class="stat"><label>Puerta de enlace</label><strong id="assetGateway">--</strong></div><div class="stat"><label>Red Wi-Fi conectada</label><strong id="assetNetwork">--</strong></div></div><form id="assetForm" class="asset-formgrid">
        <label>IP local<input name="ip" inputmode="url" autocapitalize="off" spellcheck="false" maxlength="15" placeholder="192.168.1.25" required></label>
        <label>Nombre del equipo<input name="name" maxlength="32" placeholder="Camara_Entrada" required></label>
        <label>Tipo<select name="type"><option value="Camara">Cámara</option><option value="NVR">NVR</option><option value="DVR">DVR</option><option value="Otro">Otro</option></select></label>
        <label>MAC<input name="mac" maxlength="17" placeholder="AA:BB:CC:DD:EE:FF" required></label>
        <label>Fabricante declarado<input name="manufacturer" maxlength="32" placeholder="Según etiqueta o administración"></label>
        <label>Modelo<input name="model" maxlength="32"></label>
        <label>Firmware / versión<input name="firmware" maxlength="24" placeholder="Si está disponible"></label>
        <button type="submit" id="addAssetBtn">Agregar equipo</button>
      </form><details><summary>Importar lista ARP/clientes del router</summary><p class="muted small">Pega filas CSV/TSV con IP y MAC; nombre y tipo son opcionales. Se reconocen encabezados habituales. Sin encabezado, usa IP, MAC, nombre y tipo, en ese orden. Si falta nombre se genera Equipo_IP. No pegues contraseñas. Primero exporta o copia la tabla desde el router.</p><label>Lista exportada<textarea id="assetImportText" placeholder="IP,MAC&#10;192.168.1.25,AA:BB:CC:DD:EE:FF"></textarea></label><button type="button" id="importAssetsBtn" disabled>Importar lista</button></details><p id="assetFeedback" class="muted small">Los registros se guardan en LittleFS en esta ESP32.</p></article>
      <article class="card span12"><div class="row spread"><div><h2>Equipos registrados</h2><p class="muted small">El fabricante IEEE procede de la asignación de prefijo más específica disponible (MA-L, MA-M o MA-S); no confirma el modelo ni la autenticidad y puede no coincidir con el fabricante comercial.</p></div>      <div class="row"><button id="refreshAssetsBtn" class="secondary">Actualizar</button><a class="button secondary" href="/api/cctv-assets.csv">Descargar CSV</a><button id="clearAssetsBtn" class="danger">Borrar inventario</button></div></div><div class="tablewrap"><table><thead><tr><th>IP</th><th>MAC</th><th>Nombre</th><th>Red conectada</th><th>Tipo</th><th>Fabricante / modelo</th><th>Firmware</th><th>Guía</th></tr></thead><tbody id="assetsTable"><tr><td colspan="8" class="muted">Todavía no hay equipos.</td></tr></table></div></article>
    </div>
  </section>
  <section class="tabs" id="tab-points">
    <div class="grid">
      <article class="card span12"><div class="row spread"><div><h2>Puntos registrados</h2><p class="muted small">Persistidos en LittleFS. La evaluación se calcula en la ESP32 y compara cada nombre con su medición anterior.</p></div><div class="row"><button id="refreshPointsBtn" class="secondary">Actualizar</button><button id="clearPointsBtn" class="danger">Borrar puntos</button><a class="button secondary" href="/api/points.csv">Descargar CSV</a></div></div><div class="tablewrap"><table><thead><tr><th>Tiempo (s)</th><th>Punto</th><th>Mbps</th><th>Latencia</th><th>RSSI</th><th>Canal</th><th>Score</th><th>Estado y recomendación local</th></tr></thead><tbody id="pointsTable"><tr><td colspan="8" class="muted">Todavía no hay puntos.</td></tr></tbody></table></div></article>
    </div>
  </section>
  <footer class="foot">El portal funciona localmente; la actualización IEEE requiere Internet. La evaluación de cifrado no prueba WPS ni busca vulnerabilidades explotables.</footer>
</div>
<div class="toast" id="toast"></div>
<script>
const $=id=>document.getElementById(id);
let networks=[];
let cctvAssets=[];
let toastTimer=0;
async function copyError(message,button){try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(message)}else{const field=document.createElement('textarea');field.value=message;field.readOnly=true;field.style.position='fixed';field.style.opacity='0';document.body.append(field);field.focus();field.select();field.setSelectionRange(0,field.value.length);const copied=document.execCommand('copy');field.remove();if(!copied)throw new Error('El navegador no permitió copiar')}button.textContent='Copiado'}catch(error){console.warn('No se pudo copiar el error',error);button.textContent='No se pudo copiar'}}
function toast(message,duration=3200){const el=$('toast');clearTimeout(toastTimer);el.replaceChildren();const text=document.createElement('span');text.textContent=message;el.append(text);if(duration===0){const copy=document.createElement('button');copy.className='secondary';copy.textContent='Copiar error';copy.addEventListener('click',()=>copyError(message,copy));el.append(copy);const close=document.createElement('button');close.className='secondary';close.textContent='Cerrar';close.addEventListener('click',()=>el.classList.remove('show'));el.append(close)}el.classList.add('show');if(duration>0)toastTimer=setTimeout(()=>el.classList.remove('show'),duration)}
async function request(url,options={}){const response=await fetch(url,{credentials:'same-origin',cache:'no-store',...options});if(!response.ok){let msg='Error HTTP '+response.status;try{msg=(await response.json()).error||msg}catch{}throw new Error(msg)}return response}
function parseJsonText(text){try{return JSON.parse(text)}catch(error){const excerpt=text.length>260?text.slice(0,170)+' … '+text.slice(-80):text;throw new Error('JSON inválido ('+text.length+' caracteres): '+error.message+' · '+excerpt)}}
function formBody(values){const body=new URLSearchParams();Object.keys(values).forEach(key=>body.append(key,String(values[key])));return body.toString()}
async function reportClientError(message){try{await request('/api/client-error',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:formBody({message})})}catch(error){console.warn('No se pudo enviar el error al Serial Monitor',error)}}
function formatStorageSize(mb){if(mb>=1024)return (mb/1024).toFixed(2)+' GB';if(mb>=1)return mb.toFixed(1)+' MB';return Math.round(mb*1024)+' KB'}
function renderStorageBar(summaryId,barId,ready,totalMb,usedMb){
 const summary=$(summaryId),bar=$(barId),total=Number(totalMb)||0,used=Math.min(total,Math.max(0,Number(usedMb)||0));
 bar.replaceChildren();
 if(!ready||total<=0){summary.textContent='No disponible';bar.setAttribute('aria-valuenow','0');bar.setAttribute('aria-valuetext','Almacenamiento no disponible');return}
 const free=Math.max(0,total-used),usedPercent=Math.min(100,used/total*100);
 summary.textContent='Usado: '+formatStorageSize(used)+' · Libre: '+formatStorageSize(free)+' · Total: '+formatStorageSize(total);
 const usedPart=document.createElement('span');usedPart.className='storage-used';usedPart.style.flex='0 0 '+usedPercent+'%';
 const freePart=document.createElement('span');freePart.className='storage-free';freePart.style.flex='1 1 '+(100-usedPercent)+'%';
 bar.append(usedPart,freePart);bar.setAttribute('aria-valuenow',String(Math.round(usedPercent)));bar.setAttribute('aria-valuetext',formatStorageSize(used)+' usados, '+formatStorageSize(free)+' libres');
}
function updateStorageStatus(data){
 renderStorageBar('espStorageSummary','espStorageBar',data.filesystemReady,data.filesystemTotalMb,data.filesystemUsedMb);
 renderStorageBar('sdStorageSummary','sdStorageBar',data.sdReady,data.sdTotalMb,data.sdUsedMb);
 const status=$('storageStatus');
 status.textContent=data.sdReady?'microSD montada · base OUI en '+data.ouiStorage:'microSD no montada: '+data.sdMessage+' · base OUI en '+data.ouiStorage;
 const formatButton=$('formatSdBtn'),formatFeedback=$('sdFormatFeedback'),formatProgress=$('sdFormatProgress');
 formatButton.disabled=data.sdFormatRunning||data.ouiUpdateRunning||data.ouiUploadRunning;
 for(const registry of ['L','M','S']){
  $('ouiFile'+registry).disabled=data.sdFormatRunning||data.ouiUpdateRunning||data.ouiUploadRunning;
  $('ouiUpload'+registry+'Btn').disabled=data.sdFormatRunning||data.ouiUpdateRunning||data.ouiUploadRunning;
 }
 formatProgress.classList.toggle('hidden',!data.sdFormatRunning);
 formatFeedback.textContent=data.sdFormatRunning?'Formato en curso; no retires la tarjeta.':data.sdFormatAttempted?(data.sdFormatSucceeded?'Formato completado: '+data.sdMessage:'Formato no completado: '+data.sdMessage):'El formato borra todos los archivos de la microSD.';
}
async function formatSdCard(){
 if(!confirm('Se borrarán todos los archivos de la microSD. ¿Continuar?'))return;
 const button=$('formatSdBtn');button.disabled=true;
 try{
  const result=await(await request('/api/sd/format',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:formBody({confirm:'FORMATEAR'})})).json();
  if(!result||result.ok!==true)throw new Error('El ESP32 no confirmó el inicio del formato');
  $('sdFormatFeedback').textContent='Formato en curso; no retires la tarjeta.';
  $('sdFormatProgress').classList.remove('hidden');
  toast('Formato de microSD iniciado');
  await refreshStatus();
 }catch(error){
  const detail='No se pudo iniciar el formato de la microSD: '+error.message;
  toast(detail,0);
  await refreshStatus();
 }
}
async function refreshStatus(){
 try{
  const data=await(await request('/api/status')).json();
  $('apName').textContent=data.apSsid;
  $('apIp').textContent=data.apIp;
  $('staName').textContent=data.staConnected?data.staSsid:'Sin conexión';
  $('staRssi').textContent=data.staConnected?data.rssi+' dBm':'--';
  $('staIp').textContent=data.staConnected?'http://'+data.staIp:'Sin conexión';
  $('statusMessage').textContent=data.message+' · Clientes AP: '+data.apClients;
  $('networkError').textContent=data.error||(!data.filesystemReady?'LittleFS no disponible; no se podrán guardar puntos.':'');
  $('bleStatus').textContent=data.bleProvisioningActive?'BLE activo. En la app ESP BLE Provisioning selecciona '+data.bleServiceName+' e introduce el PIN que aparece en la pantalla.':'BLE no activo. Se inicia automáticamente cuando no hay redes guardadas.';
  $('channelAdvice').textContent=data.channelAdvice;
  if($('assetGateway'))$('assetGateway').textContent=data.staConnected?data.staGateway+(data.staGatewayMac?' · '+data.staGatewayMac+(data.staGatewayManufacturer?' · IEEE: '+data.staGatewayManufacturer:' · buscando titular IEEE'):' · buscando MAC por ARP'):'Sin conexión';
  updateStorageStatus(data);
  const ouiStatus=$('ouiStatus'),ouiButton=$('updateOuiBtn');
  if(ouiStatus){
   const baseStatus='MA-L '+(data.ouiLAvailable?'lista':'falta')+' · MA-M '+(data.ouiMAvailable?'lista':'falta')+' · MA-S '+(data.ouiSAvailable?'lista':'falta');
   ouiStatus.textContent=data.ouiUpdateRunning?'Actualizando las tres bases IEEE… '+baseStatus:data.ouiUpdateSucceeded?'Las tres bases IEEE están disponibles y la actualización terminó correctamente.':data.ouiUpdateAttempted?(data.ouiAvailable?'Falló una actualización; se conservan las tres bases locales. '+baseStatus:'Actualización incompleta; estado local: '+baseStatus):data.ouiAvailable?'Las tres bases locales están disponibles; todavía no se ha intentado actualizar.':'Faltan una o más bases locales. Conecta la STA y actualiza: '+baseStatus;
   ouiButton.disabled=data.ouiUpdateRunning||data.ouiUploadRunning||data.sdFormatRunning||!data.staConnected;
  }
  const pill=$('connectionPill');
  pill.textContent=data.staConnected?'STA conectada':'Sin STA';
  pill.className='pill '+(data.staConnected?'ok':'warn');
  renderWhitelist(data.whitelist||[]);
 }catch(error){
  console.warn('No se pudo actualizar el estado del sistema',error);
  $('statusMessage').textContent='No se pudo consultar el estado del ESP32.';
 }
}
function renderWhitelist(list){const root=$('whitelist');root.replaceChildren();if(!list.length){root.textContent='Sin redes guardadas.';return}for(const ssid of list){const item=document.createElement('div');item.className='row';const dot=document.createElement('span');dot.textContent='●';dot.style.color='var(--green)';const name=document.createElement('span');name.textContent=ssid;item.append(dot,name);root.append(item)}}
function setRows(target,rows,empty,render){const root=$(target);root.replaceChildren();if(!rows.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=target==='pointsTable'?8:6;td.className='muted';td.textContent=empty;tr.append(td);root.append(tr);return}for(const row of rows){const tr=document.createElement('tr');for(const value of render(row)){const td=document.createElement('td');if(value&&typeof value==='object'){td.textContent=value.text;td.className=value.className||''}else td.textContent=value;tr.append(td)}root.append(tr)}}
async function scan(){const buttons=[$('scanBtn'),$('scanBtnOverview')].filter(Boolean);buttons.forEach(button=>{button.disabled=true;button.textContent='Escaneando…'});$('scanFeedback').textContent='Escaneando pasivamente redes 2.4 GHz…';try{const result=await(await request('/api/scan',{method:'POST'})).json();networks=result;renderScanResults();$('scanFeedback').textContent='Escaneo completo: '+result.length+' redes encontradas.';toast('Escaneo pasivo: '+result.length+' redes')}catch(e){$('scanFeedback').textContent='No se pudo completar el escaneo: '+e.message;toast(e.message)}finally{buttons.forEach(button=>{button.disabled=false;button.textContent='Escanear redes'})}}
function renderScanResults(){setRows('scanTable',networks,'No se encontraron redes.',n=>[n.ssid||'(SSID oculto)',n.bssid,n.channel,n.rssi+' dBm',n.encryption,{text:n.risk,className:n.risk.includes('Vulnerable')?'risk-high':n.risk.includes('Protegido')?'risk-protected':'risk-standard'}]);const select=$('networkSelect');select.replaceChildren();const blank=document.createElement('option');blank.value='';blank.textContent=networks.length?'Selecciona una red':'No hay redes disponibles';select.append(blank);for(const n of networks){if(!n.ssid)continue;const option=document.createElement('option');option.value=n.ssid;option.textContent=n.ssid+' · ch '+n.channel+' · '+n.rssi+' dBm';select.append(option)}drawSpectrum()}
const spectrumColors=['#5de1e6','#ff8a75','#9c8cff','#73e0ad','#ffc66d','#ff79b0','#78a9ff','#c6e36a','#e99bff','#7de0ce','#ffbd69','#a6b6ff'];
function drawSpectrum(){
 const canvas=$('spectrum'),ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
 ctx.clearRect(0,0,w,h);ctx.fillStyle='#0d1727';ctx.fillRect(0,0,w,h);
 const left=58,right=w-20,top=22,bottom=h-42;
 ctx.font='12px system-ui';ctx.lineWidth=1;
 for(let db=-30;db>=-100;db-=10){
  const y=top+(-30-db)/70*(bottom-top);
  ctx.strokeStyle='#263650';ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(right,y);ctx.stroke();
  ctx.fillStyle='#9aabc2';ctx.textAlign='right';ctx.fillText(db+' dBm',left-8,y+4);
 }
 for(let ch=1;ch<=13;ch++){
  const x=left+(ch-1)*(right-left)/12;
  ctx.strokeStyle='#1d2b40';ctx.beginPath();ctx.moveTo(x,top);ctx.lineTo(x,bottom);ctx.stroke();
  ctx.fillStyle='#a9b8cb';ctx.textAlign='center';ctx.fillText(String(ch),x,bottom+20);
 }
 ctx.fillStyle='#9aabc2';ctx.textAlign='center';ctx.fillText('Canal Wi-Fi 2.4 GHz',(left+right)/2,h-7);
 const placedLabels=[];
 networks.forEach((n,index)=>{
  if(n.channel<1||n.channel>13)return;
  const color=spectrumColors[index%spectrumColors.length];
  const x=left+(n.channel-1)*(right-left)/12;
  const y=top+Math.max(0,Math.min(70,(-30-n.rssi)))/70*(bottom-top);
  ctx.fillStyle=color+'30';ctx.strokeStyle=color+'bb';
  ctx.beginPath();ctx.moveTo(Math.max(left,x-3*(right-left)/12),bottom);
  ctx.quadraticCurveTo(x,y,Math.min(right,x+3*(right-left)/12),bottom);
  ctx.closePath();ctx.fill();ctx.stroke();
  ctx.fillStyle=color;ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill();

  const ssid=n.ssid||'(oculta)';
  const label=ssid.length>14?ssid.slice(0,13)+'…':ssid;
  ctx.font='11px system-ui';
  const textWidth=ctx.measureText(label).width;
  const labelX=Math.max(left,Math.min(right-textWidth-8,x+8));
  let labelY=Math.max(top+13,y-8);
  while(placedLabels.some(p=>Math.abs(p.x-labelX)<Math.max(p.width,textWidth+8)&&Math.abs(p.y-labelY)<14)){
   labelY+=14;
   if(labelY>bottom-3)labelY=top+13;
   if(placedLabels.length>20)break;
  }
  ctx.fillStyle='rgba(8,15,26,.88)';ctx.fillRect(labelX-3,labelY-11,textWidth+8,15);
  ctx.fillStyle=color;ctx.textAlign='left';ctx.fillText(label,labelX,labelY);
  placedLabels.push({x:labelX,y:labelY,width:textWidth+8});
 });
 const legend=$('spectrumLegend');legend.replaceChildren();
 if(!networks.length){legend.textContent='No se encontraron redes.';return}
 networks.forEach((n,index)=>{
  const item=document.createElement('div');item.className='legend-item';
  const swatch=document.createElement('span');swatch.className='legend-swatch';swatch.style.background=spectrumColors[index%spectrumColors.length];
  const text=document.createElement('span');text.className='legend-text';text.textContent=(index+1)+'. '+(n.ssid||'(SSID oculto)')+' · canal '+n.channel+' · '+n.rssi+' dBm';
  item.append(swatch,text);legend.append(item);
 });
}
async function connectNetwork(){const ssid=$('networkSelect').value,password=$('wifiPassword').value;if(!ssid){toast('Selecciona una red escaneada');return}const button=$('connectBtn');button.disabled=true;try{await request('/api/connect',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:formBody({ssid,password})});$('wifiPassword').value='';toast('Intentando conectar; se guardará si tiene éxito');setTimeout(refreshStatus,1000)}catch(e){toast(e.message)}finally{button.disabled=false}}
async function updateOui(){const button=$('updateOuiBtn');button.disabled=true;try{await request('/api/oui/update',{method:'POST'});toast('Actualización IEEE iniciada; el resultado aparecerá aquí')}catch(e){const detail='No se pudo iniciar la actualización IEEE: '+e.message;toast(detail,0)}finally{button.disabled=false;refreshStatus()}}
async function uploadOuiDatabase(registry){
 const suffix=registry.toUpperCase(),input=$('ouiFile'+suffix),button=$('ouiUpload'+suffix+'Btn'),file=input.files&&input.files[0];
 if(!file){toast('Selecciona primero el CSV '+registry);return}
 if(file.size>8*1024*1024){toast('El CSV supera el límite de 8 MB');return}
 const routes={L:'ma-l',M:'ma-m',S:'ma-s'},form=new FormData();form.append('file',file,file.name);button.disabled=true;
 $('ouiUploadFeedback').textContent='Cargando y validando MA-'+suffix+'… no retires la microSD.';
 try{
  const result=await(await request('/api/oui/upload/'+routes[suffix],{method:'POST',body:form})).json();
  if(!result||result.ok!==true||result.registry!=='MA-'+suffix)throw new Error('El ESP32 no confirmó la instalación');
  input.value='';
  $('ouiUploadFeedback').textContent='Base MA-'+suffix+' instalada y validada localmente.';
  toast('CSV MA-'+suffix+' instalado');
 }catch(error){
  const detail='No se pudo instalar MA-'+suffix+': '+error.message;
  $('ouiUploadFeedback').textContent=detail;
  toast(detail,0);
 }finally{
  await refreshStatus();
 }
}
function renderPoints(rows){setRows('pointsTable',rows,'Todavía no hay puntos.',p=>[(p.uptimeMs/1000).toFixed(1),p.name,Number(p.mbps).toFixed(2),Number(p.latencyMs).toFixed(1)+' ms',p.rssi<0?p.rssi+' dBm':'No disponible',p.channel,p.score+'/100',p.quality+'. '+p.recommendation+(p.anomaly!=='Sin anomalía'?' · '+p.anomaly:'')])}
function renderCctvAssets(){const root=$('assetsTable');root.replaceChildren();if(!cctvAssets.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=8;td.className='muted';td.textContent='Todavía no hay equipos.';tr.append(td);root.append(tr);return}for(const asset of cctvAssets){const tr=document.createElement('tr');for(const value of [asset.ip,asset.mac,asset.name,asset.networkName||'No conectada',asset.type,[asset.manufacturer||asset.ouiManufacturer,asset.model].filter(Boolean).join(' / ')||'No informado',asset.firmware||'No informado']){const td=document.createElement('td');td.textContent=value;tr.append(td)}const action=document.createElement('td'),button=document.createElement('button');button.className='secondary';button.textContent='Guía';button.addEventListener('click',()=>showCctvGuide(asset));action.append(button);tr.append(action);root.append(tr)}}
function showCctvGuide(asset){const manufacturer=asset.ouiManufacturer?' Titular IEEE: '+asset.ouiManufacturer+'.':'';$('assetGuidance').textContent='Equipo: '+asset.name+' ('+asset.type+'), IP '+asset.ip+'. La búsqueda consulta las bases MA-L, MA-M y MA-S.'+manufacturer+' Verifica el fabricante, modelo y firmware en el registro IEEE y el soporte oficial. Revisa manualmente UPnP, contraseñas predeterminadas, acceso remoto y actualizaciones; esta guía no confirma vulnerabilidades.'}
async function loadCctvAssets(){try{const [assetsResponse,statusResponse]=await Promise.all([request('/api/cctv-assets'),request('/api/status')]);cctvAssets=await assetsResponse.json();const status=await statusResponse.json();$('assetGateway').textContent=status.staConnected?status.staGateway+(status.staGatewayMac?' · '+status.staGatewayMac+(status.staGatewayManufacturer?' · IEEE: '+status.staGatewayManufacturer:' · buscando titular IEEE'):' · buscando MAC por ARP'):'Sin conexión';$('assetNetwork').textContent=status.staConnected?status.staSsid:'Sin conexión';renderCctvAssets();$('assetFeedback').textContent=cctvAssets.length+' equipos guardados localmente.';return true}catch(e){const detail='No se pudo cargar el inventario CCTV: '+e.message;$('assetFeedback').textContent=detail;toast(detail,0);return false}}
async function addCctvAsset(){const form=$('assetForm'),button=$('addAssetBtn');button.disabled=true;try{const response=await request('/api/cctv-assets',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(new FormData(form))});const result=await response.json();if(!result||result.ok!==true)throw new Error('El ESP32 no confirmó el registro');form.reset();await loadCctvAssets();$('assetFeedback').textContent='Equipo agregado. Verifica los datos en la tabla.';toast('Equipo agregado al inventario')}catch(e){const detail='No se pudo agregar el equipo: '+e.message;$('assetFeedback').textContent=detail;toast(detail,0)}finally{button.disabled=false}}
function splitImportLine(line,delimiter){const fields=[];let field='',quoted=false;for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'){if(quoted&&line[i+1]==='"'){field+='"';i++}else quoted=!quoted}else if(c===delimiter&&!quoted){fields.push(field.trim());field=''}else{field+=c}}if(quoted)throw new Error('Hay comillas sin cerrar en la lista');fields.push(field.trim());return fields}
function parseAssetImport(text){
 const lines=text.split(/\r?\n/).filter(line=>line.trim());
 if(!lines.length)throw new Error('Pega primero la lista exportada');
 const delimiter=lines[0].includes('\t')?'\t':lines[0].includes(';')?';':',';
 const first=splitImportLine(lines[0],delimiter);
 const normalize=value=>value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase();
 const aliases={ip:['ip','direccion ip','ip address','ipv4 address','internet address'],mac:['mac','mac address','direccion mac','physical address'],name:['nombre','nombre del equipo','equipo','hostname','host name','device name','client name','name'],type:['tipo','type','device type']};
 const header=first.map(normalize);
 const ipIndex=header.findIndex(value=>aliases.ip.includes(value));
 const macIndex=header.findIndex(value=>aliases.mac.includes(value));
 const nameIndex=header.findIndex(value=>aliases.name.includes(value));
 let indexes={ip:0,mac:1,name:2,type:3},start=0;
 if(ipIndex>=0&&macIndex>=0){indexes={ip:ipIndex,mac:macIndex,name:nameIndex,type:header.findIndex(value=>aliases.type.includes(value))};start=1}
 const rows=[];
 for(let i=start;i<lines.length;i++){
  const fields=splitImportLine(lines[i],delimiter),get=index=>index>=0?fields[index]||'':'';
  const ip=get(indexes.ip),mac=get(indexes.mac),rawType=get(indexes.type).trim().toLowerCase();
  if(!ip||!mac)throw new Error('Fila '+(i+1)+': faltan IP o MAC');
  const name=get(indexes.name)||'Equipo_'+ip.replace(/[^0-9A-Za-z]/g,'_');
  const type=rawType.includes('nvr')?'NVR':rawType.includes('dvr')?'DVR':rawType.includes('cam')?'Camara':'Otro';
  rows.push({ip,mac,name,type});
 }
 if(!rows.length)throw new Error('No hay filas de equipos para importar');
 if(rows.length>100)throw new Error('Importa como máximo 100 equipos por operación');
 return rows;
}
async function importCctvAssets(){const button=$('importAssetsBtn');let imported=0;button.disabled=true;try{const rows=parseAssetImport($('assetImportText').value);for(const row of rows){const response=await request('/api/cctv-assets',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:formBody(row)});const result=await response.json();if(!result||result.ok!==true)throw new Error('No se confirmó el registro de '+row.ip);imported++}await loadCctvAssets();$('assetImportText').value='';$('assetFeedback').textContent='Se importaron '+imported+' equipos.';toast('Se importaron '+imported+' equipos')}catch(e){const detail='Importación detenida después de '+imported+' equipos: '+e.message;$('assetFeedback').textContent=detail;toast(detail,0);if(imported)loadCctvAssets()}finally{button.disabled=!$('assetImportText').value.trim()}}
async function clearCctvAssets(){if(!confirm('¿Borrar todo el inventario CCTV guardado?'))return;const button=$('clearAssetsBtn');button.disabled=true;try{const response=await request('/api/cctv-assets',{method:'DELETE'});const result=await response.json();if(!result||result.ok!==true)throw new Error('El ESP32 no confirmó el borrado');cctvAssets=[];renderCctvAssets();$('assetGuidance').textContent='Selecciona “Guía” en un equipo para ver recomendaciones generales.';$('assetFeedback').textContent='Inventario vacío.';toast('Inventario borrado')}catch(e){const detail='No se pudo borrar el inventario: '+e.message;toast(detail,0)}finally{button.disabled=false}}
async function runTest(){if(!$('pointName').value.trim()){toast('Escribe un nombre para el punto');return}const button=$('runTestBtn'),message=$('testMessage');let stage='comprobar la conexión con el ESP32';button.disabled=true;message.textContent='Comprobando conexión…';try{const p0=performance.now();await request('/api/ping');const latency=performance.now()-p0;stage='medir la velocidad';message.textContent='Midiendo velocidad…';const bytes=Number($('testSize').value);const t0=performance.now();const response=await request('/api/test?bytes='+bytes);const data=await response.arrayBuffer();const elapsed=Math.max(1,performance.now()-t0);const mbps=data.byteLength*8/(elapsed/1000)/1000000;$('speedResult').textContent=mbps.toFixed(2)+' Mbps';$('latencyResult').textContent=latency.toFixed(1)+' ms';stage='guardar el punto en LittleFS';message.textContent='Velocidad medida; guardando punto…';const body=formBody({name:$('pointName').value,mbps:mbps.toFixed(3),latencyMs:latency.toFixed(2)});const recordResponse=await request('/api/record',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});stage='confirmar el guardado';const saved=parseJsonText(await recordResponse.text());if(!saved||saved.ok!==true)throw new Error('El ESP32 no confirmó el guardado del punto');message.textContent='Punto guardado en LittleFS · '+data.byteLength+' bytes';toast('Punto registrado correctamente');stage='actualizar la lista de puntos';if(!await loadPoints())message.textContent='Punto guardado, pero no se pudo actualizar la lista; revisa el mensaje de error.'}catch(e){const detail='Falló al '+stage+': '+e.message;message.textContent=detail;reportClientError(detail);toast(detail,0)}finally{button.disabled=false}}
async function loadPoints(){try{renderPoints(parseJsonText(await(await request('/api/points')).text()));return true}catch(e){const detail='No se pudo cargar Puntos guardados: '+e.message;reportClientError(detail);toast(detail,0);return false}}
async function clearPoints(){if(!confirm('¿Borrar todos los puntos guardados? Esta acción no se puede deshacer.'))return;const button=$('clearPointsBtn');button.disabled=true;try{const response=await request('/api/points',{method:'DELETE'});const result=await response.json();if(!result||result.ok!==true)throw new Error('El ESP32 no confirmó el borrado');renderPoints([]);toast('Se borraron los puntos guardados')}catch(e){const detail='No se pudieron borrar los puntos: '+e.message;reportClientError(detail);toast(detail,0)}finally{button.disabled=false}}
function selectTab(name){document.querySelectorAll('.tabs').forEach(el=>el.classList.toggle('active',el.id==='tab-'+name));document.querySelectorAll('.nav button').forEach(el=>el.classList.toggle('active',el.dataset.tab===name));if(name==='points')loadPoints();if(name==='devices')loadLanDevices();if(name==='cctv')loadCctvAssets()}
document.querySelectorAll('.nav button').forEach(button=>button.addEventListener('click',()=>selectTab(button.dataset.tab)));
$('gatewayPingBtn').addEventListener('click',async()=>{const button=$('gatewayPingBtn'),result=$('gatewayPingResult');button.disabled=true;result.textContent='Enviando un ping ICMP…';try{const data=await(await request('/api/gateway-ping')).json();result.textContent=data.reachable?'Gateway '+data.target+' respondió · '+Number(data.averageMs).toFixed(1)+' ms':'Gateway '+data.target+' no respondió al ping ICMP.'}catch(error){result.textContent='No se pudo probar el gateway: '+error.message}finally{button.disabled=false}});
$('scanBtn').addEventListener('click',scan);$('scanBtnOverview').addEventListener('click',scan);$('connectBtn').addEventListener('click',connectNetwork);$('formatSdBtn').addEventListener('click',formatSdCard);$('updateOuiBtn').addEventListener('click',updateOui);$('ouiUploadLBtn').addEventListener('click',()=>uploadOuiDatabase('L'));$('ouiUploadMBtn').addEventListener('click',()=>uploadOuiDatabase('M'));$('ouiUploadSBtn').addEventListener('click',()=>uploadOuiDatabase('S'));$('runTestBtn').addEventListener('click',runTest);$('refreshPointsBtn').addEventListener('click',loadPoints);$('clearPointsBtn').addEventListener('click',clearPoints);$('assetForm').addEventListener('submit',e=>{e.preventDefault();addCctvAsset()});$('assetImportText').addEventListener('input',e=>{$('importAssetsBtn').disabled=!e.target.value.trim()});$('importAssetsBtn').addEventListener('click',importCctvAssets);$('refreshAssetsBtn').addEventListener('click',loadCctvAssets);$('clearAssetsBtn').addEventListener('click',clearCctvAssets);
refreshStatus();setInterval(refreshStatus,5000);
</script>
<script>
let activeDevicePing=null;
let activeHttpCheck=null;
let httpCheckEntries=[];
const httpCheckCells=new Map();
async function loadLanDevices(){
 const button=document.getElementById('refreshDevicesBtn'),root=document.getElementById('lanDevicesTable'),feedback=document.getElementById('lanDevicesFeedback');
 if(activeDevicePing||activeHttpCheck){feedback.textContent='Finaliza la comprobación actual antes de actualizar la tabla.';return false}
 button.disabled=true;feedback.textContent='Cargando observaciones ARP e inventario…';
 try{
  const errors=[],fetchJson=(path,label)=>request(path).then(response=>response.json()).catch(error=>{errors.push(label+': '+error.message);return null});
  const [arpData,assetData,status]=await Promise.all([fetchJson('/api/arp-neighbors','ARP'),fetchJson('/api/cctv-assets','Inventario'),fetchJson('/api/status','Estado de red')]);
  const arpLoaded=Array.isArray(arpData),assetsLoaded=Array.isArray(assetData);
  const arpRows=Array.isArray(arpData)?arpData:[],assets=Array.isArray(assetData)?assetData:[],network=status&&status.staConnected?status.staSsid:'Sin conexión STA',devices=new Map();
  httpCheckEntries=[...new Map([...arpRows,...assets].filter(entry=>entry&&entry.ip).map(entry=>[entry.ip,{ip:entry.ip}])).values()];
  httpCheckCells.clear();
  for(const asset of assets)devices.set(asset.ip,{ip:asset.ip,network:asset.networkName||network,mac:asset.mac,manufacturer:asset.ouiManufacturer||'',name:asset.name,state:'En inventario; actividad no confirmada',arpObserved:false,inventoryImported:true});
  for(const neighbor of arpRows){const device=devices.get(neighbor.ip)||{ip:neighbor.ip,network,name:'Sin identificar',mac:'',manufacturer:'',state:'',arpObserved:false,inventoryImported:false};device.network=device.network||network;device.mac=device.mac||neighbor.mac;device.manufacturer=neighbor.manufacturer||device.manufacturer;device.state='Visto por ARP hace '+neighbor.lastSeenSeconds+' s';device.arpObserved=true;devices.set(neighbor.ip,device)}
  root.replaceChildren();
  if(!devices.size){const row=document.createElement('tr'),cell=document.createElement('td');cell.colSpan=8;cell.className='muted';cell.textContent=errors.length?'No se pudieron cargar datos: '+errors.join(' · '):'Sin vecinos ARP ni equipos en el inventario.';row.append(cell);root.append(row)}
  else for(const device of [...devices.values()].sort((a,b)=>a.ip.localeCompare(b.ip))){
   const row=document.createElement('tr');
   for(const value of [device.ip,device.network||'No informada',device.mac||'No informada',device.manufacturer||'No identificado en OUI',device.name,device.state]){
    const cell=document.createElement('td');cell.textContent=value;row.append(cell);
   }
   const action=document.createElement('td'),parts=device.ip.split('.'),validIp=parts.length===4&&parts.every(part=>/^(0|[1-9]\d{0,2})$/.test(part)&&Number(part)<=255);
   if(!validIp)action.textContent='IP no válida';
   else if(device.arpObserved||device.inventoryImported){action.textContent='Pendiente de comprobación';httpCheckCells.set(device.ip,action)}
   else action.textContent='No observada ni importada';
   row.append(action);
   const pingCell=document.createElement('td');
   if(validIp){
    const pingButton=document.createElement('button'),pingResult=document.createElement('div');
    pingButton.type='button';pingButton.className='secondary';pingButton.dataset.devicePing='true';pingButton.textContent='Iniciar ping';
    pingResult.className='muted small';pingResult.textContent='—';
    pingButton.addEventListener('click',()=>startDevicePing(device.ip,pingCell,pingResult));
    pingCell.append(pingButton,pingResult);
   }else pingCell.textContent='IP no válida';
   row.append(pingCell);root.append(row);
  }
  feedback.textContent=(devices.size?devices.size+' direcciones cargadas. ':'')+(errors.length?'Algunos datos no estuvieron disponibles: '+errors.join(' · '):'Solo se listan observaciones ARP e IP importadas del router/inventario; no es un barrido activo.');
  return arpLoaded||assetsLoaded;
 }catch(error){feedback.textContent='No se pudo actualizar la tabla: '+error.message;return false}
 finally{button.disabled=false}
}
function createHttpLink(ip,label){
 const link=document.createElement('a');
 link.href='http://'+ip+'/';link.target='_blank';link.rel='noopener noreferrer';
 link.textContent=label;link.setAttribute('aria-label','Abrir servidor HTML en '+ip);
 return link;
}
function renderHttpCheckResult(ip,data){
 const cell=httpCheckCells.get(ip);
 if(!cell)return;
 if(data.html)cell.replaceChildren(createHttpLink(ip,'Abrir HTTP'));
 else cell.textContent=data.status?'Sin HTML · HTTP '+data.status:'Sin respuesta en puerto 80';
 renderHttpCheckResultRow(ip,data);
}
function renderHttpCheckResultRow(ip,data,message=''){
 const root=document.getElementById('httpCheckResultsTable');
 if(!root)return;
 let row=[...root.querySelectorAll('tr[data-ip]')].find(entry=>entry.dataset.ip===ip);
 if(!row){
  const emptyRow=root.querySelector('[data-empty]');
  if(emptyRow)emptyRow.remove();
  row=document.createElement('tr');row.dataset.ip=ip;
  for(let i=0;i<6;i++)row.append(document.createElement('td'));
  root.append(row);
 }
 const cells=row.cells;
 cells[0].textContent=ip;cells[1].textContent='80';
 cells[2].textContent=message||(data&&data.connected?'Conectado':'Sin conexión TCP');
 cells[3].textContent=data&&Number.isFinite(Number(data.latencyMs))?Math.round(Number(data.latencyMs))+' ms':'—';
 cells[4].textContent=data&&data.status?'HTTP '+data.status:data&&data.connected?'Sin respuesta HTTP':message?'—':'Sin respuesta';
 cells[5].replaceChildren();
 if(data&&data.html)cells[5].append(createHttpLink(ip,'Abrir HTTP'));
}
function renderPingHttpResult(cell,ip,html){
 if(html){
  const link=createHttpLink(ip,'✓');
  link.title='Ping respondido; abrir servidor HTML en '+ip;
  link.style.color='var(--green)';link.style.fontSize='20px';link.style.fontWeight='800';
  cell.replaceChildren(link);
 }else{
  const marker=document.createElement('span');
  marker.textContent='×';marker.title='Ping respondido; sin servidor HTML en puerto 80';
  marker.setAttribute('aria-label','Ping respondido, servidor HTML no disponible');
  marker.style.color='var(--cyan)';marker.style.fontSize='20px';marker.style.fontWeight='800';
  cell.replaceChildren(marker);
 }
}
async function checkLanHttpServers(){
 const button=document.getElementById('checkHttpServersBtn'),feedback=document.getElementById('httpCheckFeedback');
 if(activeHttpCheck){activeHttpCheck.stop=true;feedback.textContent='Deteniendo después de la comprobación actual…';return}
 if(activeDevicePing){feedback.textContent='Finaliza el ping actual antes de comprobar HTTP.';return}
 if(!await loadLanDevices()){feedback.textContent='No se pudieron actualizar ARP e inventario. '+document.getElementById('lanDevicesFeedback').textContent;return}
 const targets=httpCheckEntries.slice(0,64),omittedTargets=httpCheckEntries.length-targets.length;
 if(!targets.length){feedback.textContent='No hay vecinos ARP ni equipos importados para comprobar.';return}
 const resultsBody=document.getElementById('httpCheckResultsTable');
 resultsBody.replaceChildren();
 for(const entry of targets)renderHttpCheckResultRow(entry.ip,null,'Pendiente');
 const run={stop:false};activeHttpCheck=run;button.textContent='Detener comprobación';document.getElementById('refreshDevicesBtn').disabled=true;
 document.querySelectorAll('[data-device-ping]').forEach(pingButton=>pingButton.disabled=true);
 let checked=0,limitMessage='';
 try{
  for(const entry of targets){
   if(run.stop)break;
   const cell=httpCheckCells.get(entry.ip);
   if(cell)cell.textContent='Comprobando puerto 80…';
   renderHttpCheckResultRow(entry.ip,null,'Comprobando…');
   try{
    const data=await(await request('/api/http-server-check?ip='+encodeURIComponent(entry.ip))).json();
    renderHttpCheckResult(entry.ip,data);
    checked++;
   }catch(error){
    if(cell)cell.textContent='No comprobado: '+error.message;
    renderHttpCheckResultRow(entry.ip,null,'No comprobado: '+error.message);
    if(error.message.includes('límite')||error.message.includes('Espera')){limitMessage=error.message;run.stop=true;break}
    checked++;
   }
   feedback.textContent=checked+' de '+targets.length+' IP comprobadas en puerto 80.'+(omittedTargets?' Se omitieron '+omittedTargets+' por el límite de 64.':'');
   if(!run.stop&&checked<targets.length)await new Promise(resolve=>setTimeout(resolve,1000));
  }
  feedback.textContent=limitMessage?'Comprobación detenida: '+limitMessage:run.stop?'Comprobación detenida; '+checked+' IP verificadas.':checked+' de '+targets.length+' IP comprobadas. Solo se enlazaron respuestas HTML.'+(omittedTargets?' Se omitieron '+omittedTargets+' por el límite de 64.':'');
 }finally{
  if(activeHttpCheck===run)activeHttpCheck=null;
  button.textContent='Corroborar HTML';document.getElementById('refreshDevicesBtn').disabled=false;
  document.querySelectorAll('[data-device-ping]').forEach(pingButton=>pingButton.disabled=false);
 }
}
async function startDevicePing(ip,cell,result){
 if(activeDevicePing||activeHttpCheck)return;
 const run={ip,stop:false,responded:false};activeDevicePing=run;
 const stopButton=document.getElementById('stopDevicePingBtn'),feedback=document.getElementById('devicePingFeedback'),buttons=document.querySelectorAll('[data-device-ping]');
 buttons.forEach(button=>button.disabled=true);stopButton.disabled=false;feedback.textContent='Ping a '+ip+' iniciado; límite de 30 segundos.';
 const deadline=Date.now()+30000;let attempts=0;
 try{
  while(activeDevicePing===run&&!run.stop&&Date.now()<deadline){
   attempts++;
   const data=await(await request('/api/device-ping?ip='+encodeURIComponent(ip))).json();
   result.textContent=data.reachable?'Respondió · '+Number(data.averageMs).toFixed(1)+' ms':'Sin respuesta · intento '+attempts;
   feedback.textContent=data.reachable?'Ping a '+ip+' · '+Number(data.averageMs).toFixed(1)+' ms · '+attempts+' intentos':'Ping a '+ip+' sin respuesta · '+attempts+' intentos';
   if(data.reachable){
    run.responded=true;run.stop=true;
    try{
     const httpData=await(await request('/api/http-server-check?ip='+encodeURIComponent(ip))).json();
     renderHttpCheckResult(ip,httpData);
     renderPingHttpResult(cell,ip,httpData.html===true);
     feedback.textContent=httpData.html?'Ping y servidor HTML confirmados para '+ip+'.':'Ping confirmado para '+ip+'; sin servidor HTML en puerto 80.';
    }catch(error){
     const marker=document.createElement('span');
     marker.textContent='?';marker.title='Ping respondió, pero no se pudo comprobar HTML: '+error.message;
     marker.setAttribute('aria-label','Ping respondió; comprobación HTML pendiente');
     marker.style.color='var(--amber)';marker.style.fontSize='20px';marker.style.fontWeight='800';
     cell.replaceChildren(marker);
     const httpCell=httpCheckCells.get(ip);
     if(httpCell)httpCell.textContent='No comprobado: '+error.message;
     result.textContent='Ping respondió; HTML no comprobado: '+error.message;
     feedback.textContent='No se pudo corroborar HTML para '+ip+': '+error.message;
    }
    break;
   }
   if(Date.now()<deadline&&!run.stop)await new Promise(resolve=>setTimeout(resolve,1000));
  }
  if(run.stop&&!run.responded){result.textContent='Ping finalizado.';feedback.textContent='Ping a '+ip+' finalizado por el usuario.'}
  else if(!run.responded&&Date.now()>=deadline){result.textContent='Límite de 30 s alcanzado.';feedback.textContent='Ping a '+ip+' finalizado al alcanzar el límite de 30 segundos.'}
 }catch(error){result.textContent='Error: '+error.message;feedback.textContent='Ping detenido: '+error.message}
 finally{
  if(activeDevicePing===run)activeDevicePing=null;
  stopButton.disabled=true;document.querySelectorAll('[data-device-ping]').forEach(button=>button.disabled=false);
 }
}
document.getElementById('refreshDevicesBtn').addEventListener('click',loadLanDevices);
document.getElementById('checkHttpServersBtn').addEventListener('click',checkLanHttpServers);
document.getElementById('stopDevicePingBtn').addEventListener('click',()=>{if(activeDevicePing){activeDevicePing.stop=true;document.getElementById('devicePingFeedback').textContent='Deteniendo después del ping actual…'}});
document.querySelectorAll('.nav button').forEach(button=>button.addEventListener('click',()=>{if(button.dataset.tab!=='devices'){if(activeDevicePing)activeDevicePing.stop=true;if(activeHttpCheck)activeHttpCheck.stop=true}}));
document.getElementById('lanDevicesTable').closest('article').after(document.getElementById('httpCheckResultsTable').closest('article'));
</script>
</body>
</html>
)HTML";

void handleRoot() {
  server.sendHeader("Cache-Control", "no-store");
  server.send_P(200, "text/html; charset=utf-8", INDEX_HTML);
}

} // namespace

void setup() {
  Serial.begin(115200);
  delay(100);
  ouiFileMutex = xSemaphoreCreateMutex();
  if (ouiFileMutex == nullptr) {
    Serial.println(F("ERROR: no se pudo crear el bloqueo de la base IEEE OUI"));
  }
  Serial.println();
  Serial.println(F("ESP32 Site Survey iniciando"));
  Serial.println(F("Escaneo pasivo; usar solo en redes autorizadas"));

  pinMode(PIN_BOOT, INPUT_PULLUP);
  initializeDisplay();
  startFilesystem();
  startSdCard();
  if (filesystemReady) {
    String initialPoints;
    if (!pointsJson(initialPoints)) {
      Serial.println(F("ERROR: no se pudo cargar el historial de puntos"));
    }
    if (!loadCctvAssets()) {
      Serial.println(F("ERROR: no se pudo cargar el inventario CCTV"));
    }
  }
  startPreferences();
  startAccessPoint();
  configureRoutes();
  initializeStaReconnect();
  startBleProvisioning(false);
  updateDisplay();
  Serial.println(F("Portal listo en http://192.168.4.1"));
}

void loop() {
  processBleProvisioningEvents();
  handleBootButton();
  if (dnsServerReady) {
    dnsServer.processNextRequest();
  }
  server.handleClient();
  maintainStaConnection();
  maintainOuiUpdate();
  maintainArpObservations();

  if ((bootQrScreen == BootQrScreen::Status) &&
      millis() >= nextScreenRefreshAt) {
    nextScreenRefreshAt = millis() + 1500UL;
    updateDisplay();
  }
  delay(2);
}
